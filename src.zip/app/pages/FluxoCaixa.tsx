import { DashboardLayout } from "../components/DashboardLayout";
import { TrendingUp, TrendingDown, Calendar } from "lucide-react";

const transactions = [
  { id: 1, date: "06/04/2026", description: "Venda - Kit Toalhas Batizado", type: "income", value: 120.00 },
  { id: 2, date: "06/04/2026", description: "Venda - Quadro Vagonite", type: "income", value: 85.00 },
  { id: 3, date: "05/04/2026", description: "Compra - Linha Branca 100m (20 unid)", type: "expense", value: 170.00 },
  { id: 4, date: "05/04/2026", description: "Venda - Kit Maternidade", type: "income", value: 180.00 },
  { id: 5, date: "04/04/2026", description: "Pagamento - Fornecedor Fios & Cia", type: "expense", value: 450.00 },
  { id: 6, date: "04/04/2026", description: "Venda - Toalha de Mesa", type: "income", value: 95.00 },
  { id: 7, date: "03/04/2026", description: "Venda - Uniforme Bordado", type: "income", value: 65.00 },
  { id: 8, date: "03/04/2026", description: "Compra - Tecido Algodão (10m)", type: "expense", value: 250.00 },
];

export function FluxoCaixa() {
  const totalIncome = transactions.filter(t => t.type === "income").reduce((sum, t) => sum + t.value, 0);
  const totalExpense = transactions.filter(t => t.type === "expense").reduce((sum, t) => sum + t.value, 0);
  const balance = totalIncome - totalExpense;

  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Fluxo de Caixa
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <Calendar className="w-8 h-8 text-blue-900 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Período</p>
            <p className="text-lg font-black text-blue-950">Abril 2026</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <TrendingUp className="w-8 h-8 text-green-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Entradas</p>
            <p className="text-2xl font-black text-green-600">R$ {totalIncome.toFixed(2)}</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <TrendingDown className="w-8 h-8 text-red-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Saídas</p>
            <p className="text-2xl font-black text-red-600">R$ {totalExpense.toFixed(2)}</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <div className={`w-8 h-8 rounded-full ${balance >= 0 ? 'bg-green-600' : 'bg-red-600'} mb-3 flex items-center justify-center text-white font-black`}>
              {balance >= 0 ? '+' : '-'}
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Saldo</p>
            <p className={`text-2xl font-black ${balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              R$ {Math.abs(balance).toFixed(2)}
            </p>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
            Movimentações Recentes
          </h2>
          <div className="space-y-3">
            {transactions.map((transaction) => (
              <div key={transaction.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:shadow transition-all">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-full ${transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'} flex items-center justify-center`}>
                    {transaction.type === 'income' ? (
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    ) : (
                      <TrendingDown className="w-6 h-6 text-red-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-bold">{transaction.description}</p>
                    <p className="text-sm text-gray-600">{transaction.date}</p>
                  </div>
                </div>
                <p className={`text-xl font-black ${transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                  {transaction.type === 'income' ? '+' : '-'} R$ {transaction.value.toFixed(2)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
