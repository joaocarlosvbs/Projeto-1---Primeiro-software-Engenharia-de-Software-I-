import { Navbar } from "../components/Navbar";
import { Mail, Phone, MapPin, Clock, Send, Instagram, Facebook, MessageSquare } from "lucide-react";
import { useState } from "react";

export function Contato() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Formulário enviado:", formData);
    alert("Mensagem enviada com sucesso! Retornaremos em breve.");
    setFormData({ name: "", email: "", phone: "", subject: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      
      <main className="p-10 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-black uppercase tracking-tighter text-blue-950 mb-4">
            Fale Conosco
          </h1>
          <p className="text-lg text-gray-700">
            Entre em contato para orçamentos, dúvidas ou sugestões
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
            <div className="bg-blue-900 p-4 rounded-xl w-fit mb-4">
              <Phone className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-black uppercase mb-2">Telefone</h3>
            <p className="text-gray-700">(16) 98877-6655</p>
            <p className="text-sm text-gray-600 mt-2">Segunda a Sexta, 8h às 18h</p>
          </div>

          <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
            <div className="bg-blue-900 p-4 rounded-xl w-fit mb-4">
              <Mail className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-black uppercase mb-2">E-mail</h3>
            <p className="text-gray-700">contato@vitrinebordados.com</p>
            <p className="text-sm text-gray-600 mt-2">Resposta em até 24h</p>
          </div>

          <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200">
            <div className="bg-blue-900 p-4 rounded-xl w-fit mb-4">
              <MapPin className="w-6 h-6 text-white" />
            </div>
            <h3 className="text-lg font-black uppercase mb-2">Localização</h3>
            <p className="text-gray-700">Assis, SP</p>
            <p className="text-sm text-gray-600 mt-2">Atendimento presencial com agendamento</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white border rounded-2xl p-8">
            <h2 className="text-2xl font-black uppercase tracking-tighter text-blue-950 mb-6">
              Envie sua Mensagem
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                  Nome Completo *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  placeholder="Seu nome"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    E-mail *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    Telefone
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                    placeholder="(00) 00000-0000"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                  Assunto *
                </label>
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                >
                  <option value="">Selecione um assunto</option>
                  <option value="orcamento">Orçamento</option>
                  <option value="pedido">Acompanhar Pedido</option>
                  <option value="duvida">Dúvida</option>
                  <option value="sugestao">Sugestão</option>
                  <option value="reclamacao">Reclamação</option>
                  <option value="outro">Outro</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                  Mensagem *
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 resize-none"
                  placeholder="Descreva sua solicitação..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-900 text-white px-6 py-4 rounded-lg font-bold uppercase hover:bg-blue-800 transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" />
                Enviar Mensagem
              </button>
            </form>
          </div>

          <div className="space-y-6">
            <div className="bg-orange-50 border border-orange-200 rounded-2xl p-8">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="w-8 h-8 text-orange-600" />
                <h3 className="text-xl font-black uppercase">Horário de Atendimento</h3>
              </div>
              <div className="space-y-3 text-gray-700">
                <div className="flex justify-between">
                  <span className="font-bold">Segunda a Sexta:</span>
                  <span>8h às 18h</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-bold">Sábado:</span>
                  <span>8h às 12h</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-bold">Domingo:</span>
                  <span>Fechado</span>
                </div>
              </div>
            </div>

            <div className="bg-white border rounded-2xl p-8">
              <div className="flex items-center gap-3 mb-4">
                <MessageSquare className="w-8 h-8 text-blue-900" />
                <h3 className="text-xl font-black uppercase">Redes Sociais</h3>
              </div>
              <p className="text-gray-700 mb-6">
                Acompanhe nosso trabalho e novidades nas redes sociais!
              </p>
              <div className="space-y-3">
                <a
                  href="#"
                  className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                >
                  <Facebook className="w-5 h-5 text-blue-600" />
                  <span className="font-bold">@vitrinebordados</span>
                </a>
                <a
                  href="#"
                  className="flex items-center gap-3 p-3 bg-pink-50 rounded-lg hover:bg-pink-100 transition-colors"
                >
                  <Instagram className="w-5 h-5 text-pink-600" />
                  <span className="font-bold">@vitrinebordados</span>
                </a>
              </div>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-2xl p-8">
              <div className="bg-green-600 p-4 rounded-xl w-fit mb-4">
                <MessageSquare className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-black uppercase mb-2">WhatsApp</h3>
              <p className="text-gray-700 mb-4">
                Para atendimento rápido, fale conosco pelo WhatsApp
              </p>
              <a
                href="https://wa.me/5516988776655"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-green-600 text-white px-6 py-3 rounded-lg font-bold uppercase hover:bg-green-700 transition-colors"
              >
                Abrir WhatsApp
              </a>
            </div>
          </div>
        </div>

        <div className="mt-12 bg-blue-50 border border-blue-200 rounded-2xl p-8 text-center">
          <h3 className="text-2xl font-black uppercase tracking-tighter text-blue-950 mb-3">
            FAQ - Perguntas Frequentes
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 text-left">
            <div>
              <h4 className="font-black text-blue-900 mb-2">Qual o prazo de entrega?</h4>
              <p className="text-gray-700 text-sm">
                O prazo varia conforme a complexidade do bordado. Em média, de 7 a 15 dias úteis.
              </p>
            </div>
            <div>
              <h4 className="font-black text-blue-900 mb-2">Fazem bordados personalizados?</h4>
              <p className="text-gray-700 text-sm">
                Sim! Criamos bordados totalmente personalizados a partir de sua ideia ou logo.
              </p>
            </div>
            <div>
              <h4 className="font-black text-blue-900 mb-2">Como funciona o orçamento?</h4>
              <p className="text-gray-700 text-sm">
                Entre em contato informando o que deseja. Faremos um orçamento sem compromisso.
              </p>
            </div>
            <div>
              <h4 className="font-black text-blue-900 mb-2">Aceitam encomendas grandes?</h4>
              <p className="text-gray-700 text-sm">
                Sim! Atendemos pedidos corporativos e em grandes quantidades com condições especiais.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
