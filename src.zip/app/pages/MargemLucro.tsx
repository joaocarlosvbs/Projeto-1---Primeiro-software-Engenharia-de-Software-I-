import { DashboardLayout } from "../components/DashboardLayout";
import { Percent } from "lucide-react";

const products = [
  { name: "Kit Toalhas Batizado", cost: 65.00, price: 120.00, sold: 15 },
  { name: "Uniforme Bordado", cost: 35.00, price: 65.00, sold: 42 },
  { name: "Quadro Vagonite", cost: 45.00, price: 85.00, sold: 23 },
  { name: "Kit Maternidade", cost: 95.00, price: 180.00, sold: 12 },
  { name: "Toalha de Mesa", cost: 52.00, price: 95.00, sold: 18 },
];

export function MargemLucro() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Margem de Lucro
        </h1>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Produto</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Custo</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Preço</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Margem</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Lucro Unit.</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Vendidos</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Lucro Total</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => {
                const margin = ((product.price - product.cost) / product.price * 100).toFixed(1);
                const unitProfit = product.price - product.cost;
                const totalProfit = unitProfit * product.sold;

                return (
                  <tr key={index} className="border-b hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold">{product.name}</td>
                    <td className="py-3 px-4 text-gray-600">R$ {product.cost.toFixed(2)}</td>
                    <td className="py-3 px-4 font-bold text-blue-900">R$ {product.price.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-purple-100 text-purple-800">
                        {margin}%
                      </span>
                    </td>
                    <td className="py-3 px-4 font-black text-green-600">R$ {unitProfit.toFixed(2)}</td>
                    <td className="py-3 px-4 text-gray-600">{product.sold}</td>
                    <td className="py-3 px-4 font-black text-green-600">R$ {totalProfit.toFixed(2)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
