import { DashboardLayout } from "../components/DashboardLayout";
import { BarChart3, Calendar, TrendingUp, Users, FileText } from "lucide-react";
import { Link } from "react-router";

const reports = [
  { title: "Vendas por Período", icon: Calendar, path: "/relatorios/vendas-periodo", color: "bg-blue-500" },
  { title: "Lucro por Produto", icon: TrendingUp, path: "/relatorios/lucro-produto", color: "bg-green-500" },
  { title: "Produtos Mais Vendidos", icon: BarChart3, path: "/relatorios/produtos-vendidos", color: "bg-purple-500" },
  { title: "Vendas por Cliente", icon: Users, path: "/relatorios/vendas-cliente", color: "bg-orange-500" },
  { title: "Clientes Aniversariantes", icon: Calendar, path: "/relatorios/aniversariantes", color: "bg-pink-500" },
];

export function Relatorios() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Relatórios Gerenciais
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reports.map((report, index) => (
            <Link key={index} to={report.path}>
              <div className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all cursor-pointer group">
                <div className={`${report.color} w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <report.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-black uppercase text-blue-950">{report.title}</h3>
                <p className="text-sm text-gray-600 mt-2">Visualizar relatório detalhado</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
