import { DashboardLayout } from "../components/DashboardLayout";
import { Plus } from "lucide-react";

const purchases = [
  { id: 1, date: "05/04/2026", supplier: "Fios & Cia", item: "Linha Branca 100m", quantity: 20, unitPrice: 8.50, total: 170.00 },
  { id: 2, date: "03/04/2026", supplier: "Tecidos Premium", item: "Tecido Algodão", quantity: 10, unitPrice: 25.00, total: 250.00 },
  { id: 3, date: "01/04/2026", supplier: "Armarinho Central", item: "Bastidores 20cm", quantity: 15, unitPrice: 15.00, total: 225.00 },
];

export function ComprasProdutos() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Compras de Produtos
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Nova Compra
          </button>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Data</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Fornecedor</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Item</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Qtd</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Valor Unit.</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Total</th>
              </tr>
            </thead>
            <tbody>
              {purchases.map((purchase) => (
                <tr key={purchase.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4">{purchase.date}</td>
                  <td className="py-3 px-4 font-bold">{purchase.supplier}</td>
                  <td className="py-3 px-4">{purchase.item}</td>
                  <td className="py-3 px-4 font-black text-blue-900">{purchase.quantity}</td>
                  <td className="py-3 px-4">R$ {purchase.unitPrice.toFixed(2)}</td>
                  <td className="py-3 px-4 font-black text-red-600">R$ {purchase.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
