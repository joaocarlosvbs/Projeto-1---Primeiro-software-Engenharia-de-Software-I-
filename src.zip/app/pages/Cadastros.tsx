import { DashboardLayout } from "../components/DashboardLayout";
import { Users, Briefcase, Package, UserCog, FileText } from "lucide-react";
import { Link } from "react-router";

const registerModules = [
  { title: "Clientes (LGPD)", icon: Users, path: "/cadastros/clientes", count: 89, color: "bg-blue-500" },
  { title: "Fornecedores", icon: Briefcase, path: "/cadastros/fornecedores", count: 12, color: "bg-orange-500" },
  { title: "Produtos", icon: Package, path: "/cadastros/produtos", count: 245, color: "bg-green-500" },
  { title: "Funcionários", icon: UserCog, path: "/cadastros/funcionarios", count: 3, color: "bg-purple-500" },
  { title: "Tipos de Produtos", icon: FileText, path: "/cadastros/tipos-produtos", count: 8, color: "bg-pink-500" },
];

export function Cadastros() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Módulo de Cadastros
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {registerModules.map((module, index) => (
            <Link key={index} to={module.path}>
              <div className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all cursor-pointer group">
                <div className={`${module.color} w-16 h-16 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <module.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-black uppercase text-blue-950 mb-2">{module.title}</h3>
                <p className="text-3xl font-black text-blue-900">{module.count}</p>
                <p className="text-sm text-gray-600 mt-2">registros cadastrados</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
