import { DashboardLayout } from "../components/DashboardLayout";
import { Plus } from "lucide-react";

const products = [
  { id: 1, name: "Kit Toalhas Batizado", category: "Kits", price: 120.00, cost: 65.00, stock: 2 },
  { id: 2, name: "Uniforme Bordado", category: "Uniformes", price: 65.00, cost: 35.00, stock: 25 },
];

export function CadastroProdutos() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Cadastro de Produtos (Ficha Técnica)
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Produto
          </button>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">ID</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Produto</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Categoria</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Custo</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Preço</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Estoque</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold text-blue-900">#{product.id.toString().padStart(3, '0')}</td>
                  <td className="py-3 px-4 font-bold">{product.name}</td>
                  <td className="py-3 px-4">{product.category}</td>
                  <td className="py-3 px-4 text-gray-600">R$ {product.cost.toFixed(2)}</td>
                  <td className="py-3 px-4 font-black text-blue-900">R$ {product.price.toFixed(2)}</td>
                  <td className="py-3 px-4 font-black text-green-600">{product.stock}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
