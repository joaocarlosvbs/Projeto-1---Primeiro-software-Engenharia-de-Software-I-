import { DashboardLayout } from "../components/DashboardLayout";
import { Plus } from "lucide-react";

const types = [
  { id: 1, name: "Kits", description: "Kits de produtos personalizados", products: 12 },
  { id: 2, name: "Uniformes", description: "Uniformes bordados para empresas", products: 5 },
  { id: 3, name: "Decoração", description: "Quadros e itens decorativos", products: 8 },
  { id: 4, name: "Mesa", description: "Toalhas e jogos americanos", products: 15 },
  { id: 5, name: "Banho", description: "Toalhas de banho e rosto", products: 20 },
];

export function TiposProdutos() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Tipos de Produtos
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Tipo
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {types.map((type) => (
            <div key={type.id} className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all">
              <h3 className="text-xl font-black uppercase text-blue-950 mb-2">{type.name}</h3>
              <p className="text-sm text-gray-600 mb-4">{type.description}</p>
              <p className="text-2xl font-black text-blue-900">{type.products} produtos</p>
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
