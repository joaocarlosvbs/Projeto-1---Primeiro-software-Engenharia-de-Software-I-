import { DashboardLayout } from "../components/DashboardLayout";
import { Cake } from "lucide-react";

const birthdays = [
  { name: "Maria Silva", date: "15/04", phone: "(16) 99876-5432", lastPurchase: "Kit Toalhas" },
  { name: "Pedro Oliveira", date: "22/04", phone: "(16) 98765-4321", lastPurchase: "Uniforme" },
  { name: "Carla Mendes", date: "30/04", phone: "(16) 97654-3210", lastPurchase: "Quadro" },
];

export function ClientesAniversariantes() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Clientes Aniversariantes
        </h1>

        <div className="bg-pink-50 border border-pink-200 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <Cake className="w-6 h-6 text-pink-600" />
            <h2 className="text-xl font-black uppercase text-pink-900">Aniversariantes do Mês</h2>
          </div>
          
          <div className="space-y-4">
            {birthdays.map((client, index) => (
              <div key={index} className="bg-white rounded-lg p-4 hover:shadow transition-all">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-bold text-lg">{client.name}</p>
                    <p className="text-sm text-gray-600">{client.phone}</p>
                    <p className="text-xs text-gray-500">Última compra: {client.lastPurchase}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-black text-pink-600">{client.date}</p>
                    <button className="mt-2 bg-pink-600 text-white px-4 py-2 rounded-lg text-xs font-bold uppercase hover:bg-pink-700">
                      Enviar Mensagem
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
