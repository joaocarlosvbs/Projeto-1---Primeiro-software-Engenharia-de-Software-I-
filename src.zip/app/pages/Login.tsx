import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Phone, Lock, User, Mail, MapPin } from "lucide-react";

export function Login() {
  const navigate = useNavigate();
  const [loginData, setLoginData] = useState({ phone: "", password: "" });
  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    password: "",
    confirmPassword: "",
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login - em produção, validar com backend
    if (loginData.phone && loginData.password) {
      // Simula diferentes tipos de usuário
      if (loginData.phone === "11999999999") {
        // Admin
        navigate("/dashboard");
      } else {
        // Cliente
        navigate("/cliente/pedidos");
      }
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock registro - em produção, enviar para backend
    if (registerData.password === registerData.confirmPassword) {
      navigate("/cliente/pedidos");
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-blue-50 to-orange-50">
      {/* Header */}
      <nav className="p-6 flex justify-between items-center border-b bg-white/80 backdrop-blur-sm">
        <Link to="/">
          <h1 className="text-xl font-black text-blue-900 uppercase italic">
            Vitrine <span className="text-orange-500 font-light">Bordados</span>
          </h1>
        </Link>
        <div className="space-x-6 text-xs font-bold uppercase tracking-widest text-gray-500">
          <Link to="/" className="hover:text-blue-900">
            Início
          </Link>
          <Link to="/vendas/portfolio" className="hover:text-blue-900">
            Produtos
          </Link>
          <Link to="/contato" className="hover:text-blue-900">
            Contato
          </Link>
        </div>
      </nav>

      {/* Login Form */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="login">Entrar</TabsTrigger>
              <TabsTrigger value="register">Criar Conta</TabsTrigger>
            </TabsList>

            {/* Login Tab */}
            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Bem-vindo de volta!</CardTitle>
                  <CardDescription>
                    Entre com seu telefone e senha para acessar o sistema
                  </CardDescription>
                </CardHeader>
                <form onSubmit={handleLogin}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="login-phone">Telefone</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="login-phone"
                          type="tel"
                          placeholder="(11) 99999-9999"
                          className="pl-10"
                          value={loginData.phone}
                          onChange={(e) =>
                            setLoginData({ ...loginData, phone: e.target.value })
                          }
                          required
                        />
                      </div>
                      <p className="text-xs text-gray-500">
                        Use <strong>11999999999</strong> para acesso admin
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="login-password">Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="login-password"
                          type="password"
                          placeholder="Digite sua senha"
                          className="pl-10"
                          value={loginData.password}
                          onChange={(e) =>
                            setLoginData({ ...loginData, password: e.target.value })
                          }
                          required
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <label className="flex items-center space-x-2 text-sm">
                        <input type="checkbox" className="rounded" />
                        <span>Lembrar-me</span>
                      </label>
                      <button
                        type="button"
                        className="text-sm text-orange-600 hover:text-orange-700"
                      >
                        Esqueci a senha
                      </button>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col space-y-4">
                    <Button
                      type="submit"
                      className="w-full bg-blue-900 hover:bg-blue-800"
                    >
                      Entrar
                    </Button>
                    <p className="text-xs text-center text-gray-500">
                      Não tem uma conta?{" "}
                      <button
                        type="button"
                        className="text-orange-600 hover:text-orange-700 font-semibold"
                        onClick={() => {
                          const registerTab = document.querySelector('[value="register"]') as HTMLButtonElement;
                          registerTab?.click();
                        }}
                      >
                        Criar conta
                      </button>
                    </p>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>

            {/* Register Tab */}
            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Criar Nova Conta</CardTitle>
                  <CardDescription>
                    Cadastre-se para fazer pedidos e acompanhar o status
                  </CardDescription>
                </CardHeader>
                <form onSubmit={handleRegister}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="register-name">Nome Completo</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-name"
                          type="text"
                          placeholder="Seu nome completo"
                          className="pl-10"
                          value={registerData.name}
                          onChange={(e) =>
                            setRegisterData({ ...registerData, name: e.target.value })
                          }
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="register-email">E-mail</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-email"
                          type="email"
                          placeholder="seu@email.com"
                          className="pl-10"
                          value={registerData.email}
                          onChange={(e) =>
                            setRegisterData({ ...registerData, email: e.target.value })
                          }
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="register-phone">Telefone</Label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-phone"
                          type="tel"
                          placeholder="(11) 99999-9999"
                          className="pl-10"
                          value={registerData.phone}
                          onChange={(e) =>
                            setRegisterData({ ...registerData, phone: e.target.value })
                          }
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="register-address">Endereço</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-address"
                          type="text"
                          placeholder="Rua, número, bairro, cidade"
                          className="pl-10"
                          value={registerData.address}
                          onChange={(e) =>
                            setRegisterData({ ...registerData, address: e.target.value })
                          }
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="register-password">Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-password"
                          type="password"
                          placeholder="Mínimo 6 caracteres"
                          className="pl-10"
                          value={registerData.password}
                          onChange={(e) =>
                            setRegisterData({ ...registerData, password: e.target.value })
                          }
                          required
                          minLength={6}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="register-confirm">Confirmar Senha</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <Input
                          id="register-confirm"
                          type="password"
                          placeholder="Digite a senha novamente"
                          className="pl-10"
                          value={registerData.confirmPassword}
                          onChange={(e) =>
                            setRegisterData({
                              ...registerData,
                              confirmPassword: e.target.value,
                            })
                          }
                          required
                          minLength={6}
                        />
                      </div>
                    </div>

                    <div className="flex items-start space-x-2">
                      <input type="checkbox" required className="mt-1 rounded" />
                      <p className="text-xs text-gray-600">
                        Concordo com os{" "}
                        <a href="#" className="text-orange-600 hover:text-orange-700">
                          Termos de Uso
                        </a>{" "}
                        e{" "}
                        <a href="#" className="text-orange-600 hover:text-orange-700">
                          Política de Privacidade (LGPD)
                        </a>
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter className="flex flex-col space-y-4">
                    <Button
                      type="submit"
                      className="w-full bg-orange-500 hover:bg-orange-600"
                    >
                      Criar Conta
                    </Button>
                    <p className="text-xs text-center text-gray-500">
                      Já tem uma conta?{" "}
                      <button
                        type="button"
                        className="text-blue-900 hover:text-blue-800 font-semibold"
                        onClick={() => {
                          const loginTab = document.querySelector('[value="login"]') as HTMLButtonElement;
                          loginTab?.click();
                        }}
                      >
                        Entrar
                      </button>
                    </p>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Info adicional */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-blue-900">
              <strong>🔒 Seus dados estão protegidos</strong>
            </p>
            <p className="text-xs text-blue-700 mt-1">
              Seguimos a LGPD e não compartilhamos suas informações pessoais.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
