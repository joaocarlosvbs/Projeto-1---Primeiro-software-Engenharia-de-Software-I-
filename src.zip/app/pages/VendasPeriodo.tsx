import { DashboardLayout } from "../components/DashboardLayout";
import { Calendar, Download, TrendingUp, DollarSign, ShoppingCart } from "lucide-react";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { useState } from "react";

const salesData = [
  { period: "Janeiro 2026", sales: 45, revenue: 5420.00, month: "Jan" },
  { period: "Fevereiro 2026", sales: 52, revenue: 6180.00, month: "Fev" },
  { period: "Março 2026", sales: 61, revenue: 7290.00, month: "Mar" },
  { period: "Abril 2026 (parcial)", sales: 23, revenue: 2840.00, month: "Abr" },
];

export function VendasPeriodo() {
  const [viewType, setViewType] = useState<"table" | "chart">("chart");

  const totalSales = salesData.reduce((sum, data) => sum + data.sales, 0);
  const totalRevenue = salesData.reduce((sum, data) => sum + data.revenue, 0);
  const avgTicket = totalRevenue / totalSales;

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Vendas por Período
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2">
            <Download className="w-5 h-5" />
            Exportar Relatório
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <ShoppingCart className="w-8 h-8 text-blue-900" />
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Total de Vendas</p>
            <p className="text-3xl font-black text-blue-950">{totalSales}</p>
            <p className="text-xs text-gray-500 mt-2">Últimos 4 meses</p>
          </div>

          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <DollarSign className="w-8 h-8 text-green-600" />
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Receita Total</p>
            <p className="text-3xl font-black text-green-600">R$ {totalRevenue.toFixed(2)}</p>
            <p className="text-xs text-gray-500 mt-2">Últimos 4 meses</p>
          </div>

          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <Calendar className="w-8 h-8 text-purple-600" />
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Ticket Médio</p>
            <p className="text-3xl font-black text-purple-600">R$ {avgTicket.toFixed(2)}</p>
            <p className="text-xs text-gray-500 mt-2">Por pedido</p>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950">
              Visualização
            </h2>
            <div className="flex gap-2">
              <button
                onClick={() => setViewType("chart")}
                className={`px-4 py-2 rounded-lg font-bold uppercase text-sm transition-colors ${
                  viewType === "chart"
                    ? "bg-blue-900 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Gráficos
              </button>
              <button
                onClick={() => setViewType("table")}
                className={`px-4 py-2 rounded-lg font-bold uppercase text-sm transition-colors ${
                  viewType === "table"
                    ? "bg-blue-900 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Tabela
              </button>
            </div>
          </div>

          {viewType === "chart" ? (
            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-black uppercase mb-4 text-blue-950">Evolução de Vendas</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={salesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="sales"
                      stroke="#1e3a8a"
                      strokeWidth={3}
                      name="Quantidade de Vendas"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div>
                <h3 className="text-lg font-black uppercase mb-4 text-blue-950">Receita por Período</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={salesData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="revenue" fill="#16a34a" name="Receita (R$)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                      Período
                    </th>
                    <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                      Qtd Vendas
                    </th>
                    <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                      Receita
                    </th>
                    <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                      Ticket Médio
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {salesData.map((data, index) => (
                    <tr key={index} className="border-b hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-bold">{data.period}</td>
                      <td className="py-3 px-4 text-blue-900 font-black">{data.sales}</td>
                      <td className="py-3 px-4 font-black text-green-600">R$ {data.revenue.toFixed(2)}</td>
                      <td className="py-3 px-4 font-bold text-purple-600">
                        R$ {(data.revenue / data.sales).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}