import { DashboardLayout } from "../components/DashboardLayout";
import { TrendingUp, DollarSign, Package, Download } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const profitData = [
  { product: "Kit Toalhas Batizado", sold: 15, revenue: 1800.00, cost: 975.00, profit: 825.00, margin: 45.8 },
  { product: "Uniforme Bordado", sold: 42, revenue: 2730.00, cost: 1470.00, profit: 1260.00, margin: 46.2 },
  { product: "Quadro Vagonite", sold: 23, revenue: 1955.00, cost: 1035.00, profit: 920.00, margin: 47.1 },
  { product: "Kit Maternidade", sold: 12, revenue: 2160.00, cost: 1152.00, profit: 1008.00, margin: 46.7 },
  { product: "Toalha de Mesa", sold: 18, revenue: 1710.00, cost: 918.00, profit: 792.00, margin: 46.3 },
];

export function LucroProduto() {
  const totalRevenue = profitData.reduce((sum, item) => sum + item.revenue, 0);
  const totalCost = profitData.reduce((sum, item) => sum + item.cost, 0);
  const totalProfit = profitData.reduce((sum, item) => sum + item.profit, 0);
  const totalSold = profitData.reduce((sum, item) => sum + item.sold, 0);

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Lucro por Produto
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2">
            <Download className="w-5 h-5" />
            Exportar Relatório
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <Package className="w-8 h-8 text-blue-900" />
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Total Vendido</p>
            <p className="text-3xl font-black text-blue-950">{totalSold}</p>
            <p className="text-xs text-gray-500 mt-2">Unidades</p>
          </div>

          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <DollarSign className="w-8 h-8 text-blue-600" />
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Receita Total</p>
            <p className="text-3xl font-black text-blue-600">R$ {totalRevenue.toFixed(2)}</p>
          </div>

          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <DollarSign className="w-8 h-8 text-red-600" />
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Custo Total</p>
            <p className="text-3xl font-black text-red-600">R$ {totalCost.toFixed(2)}</p>
          </div>

          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center justify-between mb-3">
              <DollarSign className="w-8 h-8 text-green-600" />
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Lucro Total</p>
            <p className="text-3xl font-black text-green-600">R$ {totalProfit.toFixed(2)}</p>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
            Comparativo de Lucro por Produto
          </h2>
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={profitData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="product" angle={-15} textAnchor="end" height={100} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="revenue" fill="#1e3a8a" name="Receita" />
              <Bar dataKey="cost" fill="#dc2626" name="Custo" />
              <Bar dataKey="profit" fill="#16a34a" name="Lucro" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
            Detalhamento por Produto
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Produto</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Vendidos</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Receita</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Custo</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Lucro</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Margem</th>
                </tr>
              </thead>
              <tbody>
                {profitData.map((item, index) => (
                  <tr key={index} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold">{item.product}</td>
                    <td className="py-3 px-4 font-black text-blue-900">{item.sold}</td>
                    <td className="py-3 px-4 font-black text-blue-900">R$ {item.revenue.toFixed(2)}</td>
                    <td className="py-3 px-4 text-gray-600">R$ {item.cost.toFixed(2)}</td>
                    <td className="py-3 px-4 font-black text-green-600">R$ {item.profit.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-green-100 text-green-800">
                        {item.margin.toFixed(1)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}