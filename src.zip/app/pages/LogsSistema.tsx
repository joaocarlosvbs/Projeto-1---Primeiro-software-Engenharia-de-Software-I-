import { DashboardLayout } from "../components/DashboardLayout";
import { Search, Download, Filter, Activity, User, ShoppingCart, Package, DollarSign, Settings, AlertTriangle } from "lucide-react";
import { useState } from "react";

const logTypes = [
  { type: "user", label: "Usuário", icon: User, color: "bg-blue-500" },
  { type: "sale", label: "Venda", icon: ShoppingCart, color: "bg-green-500" },
  { type: "stock", label: "Estoque", icon: Package, color: "bg-purple-500" },
  { type: "financial", label: "Financeiro", icon: DollarSign, color: "bg-yellow-500" },
  { type: "config", label: "Configuração", icon: Settings, color: "bg-gray-500" },
  { type: "error", label: "Erro", icon: AlertTriangle, color: "bg-red-500" },
];

const logs = [
  {
    id: 1,
    timestamp: "06/04/2026 14:35:22",
    user: "admin@vitrinebordados.com",
    action: "Login realizado com sucesso",
    type: "user",
    ip: "192.168.1.105",
    details: "Acesso via navegador Chrome",
  },
  {
    id: 2,
    timestamp: "06/04/2026 14:30:15",
    user: "maria@vitrinebordados.com",
    action: "Nova venda cadastrada (#0045)",
    type: "sale",
    ip: "192.168.1.108",
    details: "Cliente: João Santos - Valor: R$ 350,00",
  },
  {
    id: 3,
    timestamp: "06/04/2026 14:25:40",
    user: "maria@vitrinebordados.com",
    action: "Atualização de estoque - Linha Preta",
    type: "stock",
    ip: "192.168.1.108",
    details: "Quantidade alterada de 50 para 45 unidades",
  },
  {
    id: 4,
    timestamp: "06/04/2026 14:20:10",
    user: "admin@vitrinebordados.com",
    action: "Pagamento recebido (#0042)",
    type: "financial",
    ip: "192.168.1.105",
    details: "Forma: PIX - Valor: R$ 280,00",
  },
  {
    id: 5,
    timestamp: "06/04/2026 14:15:33",
    user: "admin@vitrinebordados.com",
    action: "Configuração alterada - Alerta de estoque mínimo",
    type: "config",
    ip: "192.168.1.105",
    details: "Valor anterior: 10 | Novo valor: 5",
  },
  {
    id: 6,
    timestamp: "06/04/2026 14:10:05",
    user: "joao@vitrinebordados.com",
    action: "Tentativa de acesso negada",
    type: "error",
    ip: "192.168.1.120",
    details: "Credenciais inválidas - 3ª tentativa",
  },
  {
    id: 7,
    timestamp: "06/04/2026 13:45:18",
    user: "maria@vitrinebordados.com",
    action: "Produto cadastrado - Kit Maternidade Azul",
    type: "stock",
    ip: "192.168.1.108",
    details: "Código: PRD-089 - Preço: R$ 180,00",
  },
  {
    id: 8,
    timestamp: "06/04/2026 13:30:42",
    user: "admin@vitrinebordados.com",
    action: "Relatório de vendas gerado",
    type: "financial",
    ip: "192.168.1.105",
    details: "Período: 01/04/2026 a 06/04/2026",
  },
];

export function LogsSistema() {
  const [selectedType, setSelectedType] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredLogs = logs.filter((log) => {
    const matchesType = selectedType === "all" || log.type === selectedType;
    const matchesSearch =
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.user.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  const getLogIcon = (type: string) => {
    const logType = logTypes.find((t) => t.type === type);
    return logType || logTypes[0];
  };

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Logs do Sistema
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2">
            <Download className="w-5 h-5" />
            Exportar Logs
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-6 flex items-center gap-3">
          <Activity className="w-6 h-6 text-blue-900" />
          <div>
            <p className="font-bold text-blue-900">Auditoria e Rastreabilidade</p>
            <p className="text-sm text-blue-800">
              Registro completo de todas as ações realizadas no sistema para conformidade e segurança
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
          <button
            onClick={() => setSelectedType("all")}
            className={`p-4 rounded-xl border-2 transition-all ${
              selectedType === "all"
                ? "border-blue-900 bg-blue-50"
                : "border-gray-200 bg-white hover:border-blue-300"
            }`}
          >
            <Filter className="w-6 h-6 text-blue-900 mx-auto mb-2" />
            <p className="text-xs font-bold uppercase text-center">Todos</p>
            <p className="text-lg font-black text-blue-900 text-center">{logs.length}</p>
          </button>
          {logTypes.map((logType) => {
            const count = logs.filter((log) => log.type === logType.type).length;
            return (
              <button
                key={logType.type}
                onClick={() => setSelectedType(logType.type)}
                className={`p-4 rounded-xl border-2 transition-all ${
                  selectedType === logType.type
                    ? "border-blue-900 bg-blue-50"
                    : "border-gray-200 bg-white hover:border-blue-300"
                }`}
              >
                <div className={`${logType.color} p-2 rounded-lg mx-auto w-10 h-10 flex items-center justify-center mb-2`}>
                  <logType.icon className="w-5 h-5 text-white" />
                </div>
                <p className="text-xs font-bold uppercase text-center">{logType.label}</p>
                <p className="text-lg font-black text-blue-900 text-center">{count}</p>
              </button>
            );
          })}
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar nos logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
            />
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
            Registro de Atividades ({filteredLogs.length})
          </h2>
          <div className="space-y-4">
            {filteredLogs.map((log) => {
              const logIcon = getLogIcon(log.type);
              return (
                <div
                  key={log.id}
                  className="border rounded-xl p-4 hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-start gap-4">
                    <div className={`${logIcon.color} p-3 rounded-lg flex-shrink-0`}>
                      <logIcon.icon className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-bold text-blue-950">{log.action}</p>
                          <p className="text-sm text-gray-600 mt-1">{log.details}</p>
                        </div>
                        <span className="text-xs text-gray-500 whitespace-nowrap ml-4">
                          {log.timestamp}
                        </span>
                      </div>
                      <div className="flex gap-4 text-xs text-gray-500 mt-3 pt-3 border-t">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {log.user}
                        </span>
                        <span className="flex items-center gap-1">
                          <Activity className="w-3 h-3" />
                          IP: {log.ip}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredLogs.length === 0 && (
            <div className="text-center py-12">
              <Activity className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">Nenhum log encontrado para os filtros selecionados</p>
            </div>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
