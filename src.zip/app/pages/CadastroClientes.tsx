import { DashboardLayout } from "../components/DashboardLayout";
import { Plus, Search, Edit, Trash2, Shield } from "lucide-react";

const clients = [
  { id: 1, name: "Maria Silva", email: "maria@email.com", phone: "(16) 99876-5432", city: "Assis", orders: 8 },
  { id: 2, name: "João Santos", email: "joao@email.com", phone: "(16) 98765-4321", city: "Assis", orders: 5 },
  { id: 3, name: "Ana Costa", email: "ana@email.com", phone: "(16) 97654-3210", city: "Marília", orders: 4 },
];

export function CadastroClientes() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Cadastro de Clientes
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Cliente
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-6 flex items-center gap-3">
          <Shield className="w-6 h-6 text-blue-900" />
          <div>
            <p className="font-bold text-blue-900">Conformidade LGPD</p>
            <p className="text-sm text-blue-800">Todos os dados são protegidos conforme a Lei Geral de Proteção de Dados</p>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar clientes..."
              className="w-full pl-12 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
            />
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">ID</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Nome</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Email</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Telefone</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Cidade</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Pedidos</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Ações</th>
              </tr>
            </thead>
            <tbody>
              {clients.map((client) => (
                <tr key={client.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold text-blue-900">#{client.id.toString().padStart(3, '0')}</td>
                  <td className="py-3 px-4 font-bold">{client.name}</td>
                  <td className="py-3 px-4 text-gray-600">{client.email}</td>
                  <td className="py-3 px-4 text-gray-600">{client.phone}</td>
                  <td className="py-3 px-4">{client.city}</td>
                  <td className="py-3 px-4 font-black text-blue-900">{client.orders}</td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-blue-50 rounded">
                        <Edit className="w-4 h-4 text-blue-900" />
                      </button>
                      <button className="p-2 hover:bg-red-50 rounded">
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
