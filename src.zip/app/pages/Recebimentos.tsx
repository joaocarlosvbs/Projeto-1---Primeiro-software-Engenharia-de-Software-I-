import { DashboardLayout } from "../components/DashboardLayout";
import { CreditCard, Check, Clock } from "lucide-react";

const receivables = [
  { id: 1, client: "Maria Silva", description: "Kit Toalhas Batizado", value: 120.00, date: "10/04/2026", status: "pending" },
  { id: 2, client: "João Santos", description: "Uniforme Bordado (Sinal 50%)", value: 32.50, date: "08/04/2026", status: "pending" },
  { id: 3, client: "Ana Costa", description: "Quadro Vagonite", value: 85.00, date: "07/04/2026", status: "received" },
  { id: 4, client: "Pedro Oliveira", description: "Kit Maternidade", value: 180.00, date: "12/04/2026", status: "pending" },
  { id: 5, client: "Carla Mendes", description: "Toalha de Mesa", value: 95.00, date: "02/04/2026", status: "received" },
];

export function Recebimentos() {
  const pending = receivables.filter(r => r.status === "pending").reduce((sum, r) => sum + r.value, 0);
  const received = receivables.filter(r => r.status === "received").reduce((sum, r) => sum + r.value, 0);

  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Recebimentos de Clientes
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <CreditCard className="w-8 h-8 text-blue-900 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Total a Receber</p>
            <p className="text-3xl font-black text-blue-950">R$ {(pending + received).toFixed(2)}</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Clock className="w-8 h-8 text-orange-500 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Pendentes</p>
            <p className="text-3xl font-black text-orange-500">R$ {pending.toFixed(2)}</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Check className="w-8 h-8 text-green-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Recebidos</p>
            <p className="text-3xl font-black text-green-600">R$ {received.toFixed(2)}</p>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
            Listagem de Recebimentos
          </h2>
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Cliente</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Descrição</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Valor</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Vencimento</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Status</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Ação</th>
              </tr>
            </thead>
            <tbody>
              {receivables.map((item) => (
                <tr key={item.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold">{item.client}</td>
                  <td className="py-3 px-4">{item.description}</td>
                  <td className="py-3 px-4 font-black text-blue-900">R$ {item.value.toFixed(2)}</td>
                  <td className="py-3 px-4">{item.date}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                      item.status === "received" ? "bg-green-100 text-green-800" : "bg-orange-100 text-orange-800"
                    }`}>
                      {item.status === "received" ? "Recebido" : "Pendente"}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    {item.status === "pending" && (
                      <button className="bg-green-600 text-white px-4 py-2 rounded-lg font-bold text-xs uppercase hover:bg-green-700">
                        Confirmar
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
