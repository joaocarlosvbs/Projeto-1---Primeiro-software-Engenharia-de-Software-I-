import { Navbar } from "../components/Navbar";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { ArrowRight, Star, Heart, Package } from "lucide-react";

const products = [
  {
    title: "Kit Toalhas Batizado Personalizadas",
    price: "A partir de R$ 120,00",
    image: "https://images.unsplash.com/photo-1630790676734-3770bbd14a0a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbWJyb2lkZXJ5JTIwYmFwdGlzbSUyMHRvd2VscyUyMGtpdHxlbnwxfHx8fDE3NzU0Nzg3MDF8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    title: "Uniformes Bordados (Logo Empresa)",
    price: "Sob Orçamento",
    image: "https://images.unsplash.com/photo-1585647805414-dffb0a2a7a23?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbWJyb2lkZXJlZCUyMHVuaWZvcm0lMjBsb2dvfGVufDF8fHx8MTc3NTQ3ODcwMnww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    title: "Quadros Decorativos Vagonite",
    price: "R$ 85,00",
    image: "https://images.unsplash.com/photo-1771909752761-d26abe4e60ba?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWNvcmF0aXZlJTIwZW1icm9pZGVyeSUyMGZyYW1lJTIwYXJ0fGVufDF8fHx8MTc3NTQ3ODcwM3ww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    title: "Bordados Personalizados",
    price: "A partir de R$ 45,00",
    image: "https://images.unsplash.com/photo-1628068431732-b8d752c52523?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b20lMjBlbWJyb2lkZXJ5JTIwZGVzaWdufGVufDF8fHx8MTc3NTQ3ODcwM3ww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    title: "Kit Maternidade Completo",
    price: "R$ 180,00",
    image: "https://images.unsplash.com/photo-1629442214769-c4f01458bf04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWJ5JTIwbWF0ZXJuaXR5JTIwZW1icm9pZGVyeSUyMGtpdHxlbnwxfHx8fDE3NzU0Nzg3MDN8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    title: "Toalhas de Mesa Bordadas",
    price: "A partir de R$ 95,00",
    image: "https://images.unsplash.com/photo-1692651435527-a3ecf950ae30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbWJyb2lkZXJlZCUyMHRhYmxlY2xvdGh8ZW58MXx8fHwxNzc1NDc4NzAzfDA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

const testimonials = [
  {
    name: "Maria Santos",
    text: "O kit de batizado ficou perfeito! Bordado delicado e acabamento impecável.",
    rating: 5,
  },
  {
    name: "João Silva",
    text: "Uniformes da empresa ficaram incríveis. Atendimento nota 10!",
    rating: 5,
  },
  {
    name: "Ana Costa",
    text: "Adorei o quadro personalizado! Superou minhas expectativas.",
    rating: 5,
  },
];

export function Home() {
  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-950 to-blue-800 text-white py-20 px-10">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-black uppercase tracking-tighter mb-6">
            Vitrine Bordados
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
            Transformamos suas ideias em bordados artesanais de alta qualidade
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#produtos"
              className="bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-lg font-bold uppercase transition-colors flex items-center justify-center gap-2"
            >
              Ver Produtos
              <ArrowRight className="w-5 h-5" />
            </a>
            <a
              href="/contato"
              className="bg-white hover:bg-gray-100 text-blue-950 px-8 py-4 rounded-lg font-bold uppercase transition-colors"
            >
              Solicitar Orçamento
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-10 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-black uppercase mb-2">Qualidade Premium</h3>
              <p className="text-gray-700">Bordados artesanais com acabamento profissional</p>
            </div>
            <div className="text-center">
              <div className="bg-orange-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-black uppercase mb-2">Personalização Total</h3>
              <p className="text-gray-700">Criamos exatamente o que você imaginou</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-black uppercase mb-2">Entrega Garantida</h3>
              <p className="text-gray-700">Cumprimos prazos com segurança e cuidado</p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <main id="produtos" className="p-10">
        <h2 className="text-3xl font-black text-center mb-12 uppercase tracking-tighter text-blue-950">
          Nossas Criações
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 max-w-7xl mx-auto">
          {products.map((product, index) => (
            <div key={index} className="group cursor-pointer">
              <div className="h-64 bg-slate-100 rounded-3xl mb-4 overflow-hidden">
                <ImageWithFallback
                  src={product.image}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
              </div>
              <h4 className="font-bold text-center text-sm uppercase">
                {product.title}
              </h4>
              <p className="text-center text-blue-900 font-black mt-1">
                {product.price}
              </p>
            </div>
          ))}
        </div>
      </main>

      {/* Testimonials Section */}
      <section className="py-16 px-10 bg-blue-950 text-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-black text-center mb-12 uppercase tracking-tighter">
            O que dizem nossos clientes
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-blue-900 rounded-2xl p-6">
                <div className="flex mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-orange-500 text-orange-500" />
                  ))}
                </div>
                <p className="mb-4 italic">&quot;{testimonial.text}&quot;</p>
                <p className="font-bold">— {testimonial.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-10 bg-gradient-to-r from-orange-500 to-orange-600 text-white text-center">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-black uppercase tracking-tighter mb-4">
            Pronto para criar seu bordado personalizado?
          </h2>
          <p className="text-xl mb-8">
            Entre em contato e receba um orçamento sem compromisso
          </p>
          <a
            href="/contato"
            className="inline-block bg-white hover:bg-gray-100 text-blue-950 px-8 py-4 rounded-lg font-bold uppercase transition-colors"
          >
            Solicitar Orçamento
          </a>
        </div>
      </section>
    </div>
  );
}