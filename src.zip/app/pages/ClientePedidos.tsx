import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { 
  Package, 
  Search, 
  ShoppingBag, 
  Clock, 
  CheckCircle, 
  XCircle,
  Eye,
  Plus,
  User,
  LogOut
} from "lucide-react";

const mockPedidos = [
  {
    id: "PED-001",
    data: "2026-04-01",
    produtos: "Kit Toalhas Batizado (2 unidades)",
    valor: 240.00,
    status: "Em Produção",
    statusColor: "bg-blue-500",
    prazo: "2026-04-15",
  },
  {
    id: "PED-002",
    data: "2026-03-25",
    produtos: "Uniforme Bordado (5 unidades)",
    valor: 350.00,
    status: "Aguardando Aprovação",
    statusColor: "bg-yellow-500",
    prazo: "2026-04-10",
  },
  {
    id: "PED-003",
    data: "2026-03-15",
    produtos: "Quadro Decorativo Vagonite",
    valor: 85.00,
    status: "Concluído",
    statusColor: "bg-green-500",
    prazo: "2026-03-20",
    entrega: "2026-03-19",
  },
  {
    id: "PED-004",
    data: "2026-02-28",
    produtos: "Kit Maternidade Completo",
    valor: 180.00,
    status: "Entregue",
    statusColor: "bg-green-600",
    prazo: "2026-03-10",
    entrega: "2026-03-08",
  },
];

export function ClientePedidos() {
  const [searchTerm, setSearchTerm] = useState("");
  
  const filteredPedidos = mockPedidos.filter(
    (pedido) =>
      pedido.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pedido.produtos.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const pedidosAtivos = filteredPedidos.filter(
    (p) => p.status !== "Entregue" && p.status !== "Cancelado"
  );

  const pedidosHistorico = filteredPedidos.filter(
    (p) => p.status === "Entregue" || p.status === "Cancelado"
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Em Produção":
        return <Clock className="h-4 w-4" />;
      case "Concluído":
        return <CheckCircle className="h-4 w-4" />;
      case "Entregue":
        return <CheckCircle className="h-4 w-4" />;
      case "Cancelado":
        return <XCircle className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-orange-50">
      {/* Header */}
      <nav className="p-6 flex justify-between items-center border-b bg-white/80 backdrop-blur-sm">
        <Link to="/">
          <h1 className="text-xl font-black text-blue-900 uppercase italic">
            Vitrine <span className="text-orange-500 font-light">Bordados</span>
          </h1>
        </Link>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2 text-sm text-gray-700">
            <User className="h-4 w-4" />
            <span>Maria Santos</span>
          </div>
          <Link 
            to="/login" 
            className="flex items-center space-x-2 text-sm text-gray-500 hover:text-red-600"
          >
            <LogOut className="h-4 w-4" />
            <span>Sair</span>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto p-6 max-w-6xl">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-blue-900 mb-2">Meus Pedidos</h1>
          <p className="text-gray-600">
            Acompanhe o status dos seus pedidos e faça novas encomendas
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Pedidos Ativos</CardDescription>
              <CardTitle className="text-3xl text-blue-900">
                {pedidosAtivos.length}
              </CardTitle>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Em Produção</CardDescription>
              <CardTitle className="text-3xl text-orange-500">
                {mockPedidos.filter((p) => p.status === "Em Produção").length}
              </CardTitle>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Concluídos</CardDescription>
              <CardTitle className="text-3xl text-green-600">
                {mockPedidos.filter((p) => p.status === "Entregue").length}
              </CardTitle>
            </CardHeader>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardDescription>Total Gasto</CardDescription>
              <CardTitle className="text-3xl text-blue-900">
                R$ {mockPedidos.reduce((acc, p) => acc + p.valor, 0).toFixed(2)}
              </CardTitle>
            </CardHeader>
          </Card>
        </div>

        {/* Search and New Order */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar por número do pedido ou produto..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Link to="/vendas/portfolio">
            <Button className="bg-orange-500 hover:bg-orange-600 w-full sm:w-auto">
              <Plus className="h-4 w-4 mr-2" />
              Novo Pedido
            </Button>
          </Link>
        </div>

        {/* Pedidos Tabs */}
        <Tabs defaultValue="ativos" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="ativos">
              Pedidos Ativos ({pedidosAtivos.length})
            </TabsTrigger>
            <TabsTrigger value="historico">
              Histórico ({pedidosHistorico.length})
            </TabsTrigger>
          </TabsList>

          {/* Pedidos Ativos */}
          <TabsContent value="ativos" className="space-y-4">
            {pedidosAtivos.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <ShoppingBag className="h-16 w-16 text-gray-300 mb-4" />
                  <p className="text-gray-500 text-center mb-4">
                    Você não tem pedidos ativos no momento
                  </p>
                  <Link to="/vendas/portfolio">
                    <Button className="bg-orange-500 hover:bg-orange-600">
                      Fazer Novo Pedido
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              pedidosAtivos.map((pedido) => (
                <Card key={pedido.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg text-blue-900">
                          {pedido.id}
                        </CardTitle>
                        <CardDescription>
                          Pedido realizado em {new Date(pedido.data).toLocaleDateString('pt-BR')}
                        </CardDescription>
                      </div>
                      <Badge className={`${pedido.statusColor} text-white`}>
                        <span className="flex items-center gap-1">
                          {getStatusIcon(pedido.status)}
                          {pedido.status}
                        </span>
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-semibold text-gray-900">{pedido.produtos}</p>
                          <p className="text-sm text-gray-500">
                            Prazo de entrega: {new Date(pedido.prazo).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                        <p className="text-xl font-bold text-blue-900">
                          R$ {pedido.valor.toFixed(2)}
                        </p>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="h-4 w-4 mr-2" />
                          Ver Detalhes
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-orange-600 border-orange-600 hover:bg-orange-50"
                        >
                          Contatar Vendedor
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          {/* Histórico */}
          <TabsContent value="historico" className="space-y-4">
            {pedidosHistorico.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Package className="h-16 w-16 text-gray-300 mb-4" />
                  <p className="text-gray-500 text-center">
                    Você ainda não tem pedidos concluídos
                  </p>
                </CardContent>
              </Card>
            ) : (
              pedidosHistorico.map((pedido) => (
                <Card key={pedido.id} className="hover:shadow-lg transition-shadow opacity-90">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg text-blue-900">
                          {pedido.id}
                        </CardTitle>
                        <CardDescription>
                          Pedido realizado em {new Date(pedido.data).toLocaleDateString('pt-BR')}
                        </CardDescription>
                      </div>
                      <Badge className={`${pedido.statusColor} text-white`}>
                        <span className="flex items-center gap-1">
                          {getStatusIcon(pedido.status)}
                          {pedido.status}
                        </span>
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="font-semibold text-gray-900">{pedido.produtos}</p>
                          <p className="text-sm text-gray-500">
                            Entregue em {pedido.entrega ? new Date(pedido.entrega).toLocaleDateString('pt-BR') : '-'}
                          </p>
                        </div>
                        <p className="text-xl font-bold text-blue-900">
                          R$ {pedido.valor.toFixed(2)}
                        </p>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="h-4 w-4 mr-2" />
                          Ver Detalhes
                        </Button>
                        <Button 
                          size="sm" 
                          className="bg-orange-500 hover:bg-orange-600"
                        >
                          Pedir Novamente
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
