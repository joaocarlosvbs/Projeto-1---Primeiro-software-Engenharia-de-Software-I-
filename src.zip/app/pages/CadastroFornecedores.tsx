import { DashboardLayout } from "../components/DashboardLayout";
import { Plus, Search } from "lucide-react";

const suppliers = [
  { id: 1, name: "Fios & Cia", contact: "João", phone: "(16) 3322-1100", email: "contato@fiosecia.com" },
  { id: 2, name: "Tecidos Premium", contact: "Maria", phone: "(16) 3322-2200", email: "vendas@tecidospremium.com" },
  { id: 3, name: "Armarinho Central", contact: "Pedro", phone: "(16) 3322-3300", email: "armarinho@central.com" },
];

export function CadastroFornecedores() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Cadastro de Fornecedores
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Fornecedor
          </button>
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar fornecedores..."
              className="w-full pl-12 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
            />
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">ID</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Fornecedor</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Contato</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Telefone</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Email</th>
              </tr>
            </thead>
            <tbody>
              {suppliers.map((supplier) => (
                <tr key={supplier.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold text-blue-900">#{supplier.id.toString().padStart(3, '0')}</td>
                  <td className="py-3 px-4 font-bold">{supplier.name}</td>
                  <td className="py-3 px-4">{supplier.contact}</td>
                  <td className="py-3 px-4 text-gray-600">{supplier.phone}</td>
                  <td className="py-3 px-4 text-gray-600">{supplier.email}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
