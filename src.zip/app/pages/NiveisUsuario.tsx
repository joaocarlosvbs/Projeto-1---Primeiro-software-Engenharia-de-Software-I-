import { DashboardLayout } from "../components/DashboardLayout";
import { Plus, Search, Edit, Trash2, Shield, Key, User } from "lucide-react";
import { useState } from "react";

const users = [
  { 
    id: 1, 
    name: "Admin Sistema", 
    email: "admin@vitrinebordados.com", 
    role: "Administrador", 
    status: "Ativo",
    lastAccess: "06/04/2026 14:35"
  },
  { 
    id: 2, 
    name: "Maria Operadora", 
    email: "maria@vitrinebordados.com", 
    role: "Operador", 
    status: "Ativo",
    lastAccess: "06/04/2026 10:20"
  },
  { 
    id: 3, 
    name: "João Consulta", 
    email: "joao@vitrinebordados.com", 
    role: "Visualizador", 
    status: "Inativo",
    lastAccess: "28/03/2026 16:15"
  },
];

const roles = [
  {
    name: "Administrador",
    color: "bg-red-500",
    permissions: ["Acesso total", "Gerenciar usuários", "Configurações do sistema", "Exclusão de dados"],
    icon: Shield,
  },
  {
    name: "Operador",
    color: "bg-blue-500",
    permissions: ["Cadastros", "Vendas", "Estoque", "Relatórios básicos"],
    icon: Key,
  },
  {
    name: "Visualizador",
    color: "bg-gray-500",
    permissions: ["Visualizar relatórios", "Consultar dados", "Apenas leitura"],
    icon: User,
  },
];

export function NiveisUsuario() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredUsers = users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Níveis de Usuário
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Usuário
          </button>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mb-6 flex items-center gap-3">
          <Shield className="w-6 h-6 text-blue-900" />
          <div>
            <p className="font-bold text-blue-900">RBAC - Role-Based Access Control</p>
            <p className="text-sm text-blue-800">
              Sistema de controle de acesso baseado em funções para segurança total
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {roles.map((role) => (
            <div key={role.name} className="bg-white border rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className={`${role.color} p-3 rounded-xl`}>
                  <role.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-black uppercase">{role.name}</h3>
              </div>
              <div className="space-y-2">
                {role.permissions.map((permission, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm">
                    <div className="w-1.5 h-1.5 bg-blue-900 rounded-full"></div>
                    <span className="text-gray-700">{permission}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar usuários..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
            />
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
            Usuários Cadastrados
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    ID
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Nome
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Email
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Nível de Acesso
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Status
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Último Acesso
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold text-blue-900">
                      #{user.id.toString().padStart(3, "0")}
                    </td>
                    <td className="py-3 px-4 font-bold">{user.name}</td>
                    <td className="py-3 px-4 text-gray-600">{user.email}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                          user.role === "Administrador"
                            ? "bg-red-100 text-red-800"
                            : user.role === "Operador"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {user.role}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                          user.status === "Ativo"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {user.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-600">{user.lastAccess}</td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button className="p-2 hover:bg-blue-50 rounded transition-colors">
                          <Edit className="w-4 h-4 text-blue-900" />
                        </button>
                        <button className="p-2 hover:bg-red-50 rounded transition-colors">
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
