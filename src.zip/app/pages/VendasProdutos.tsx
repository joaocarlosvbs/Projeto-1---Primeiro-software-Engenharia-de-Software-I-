import { DashboardLayout } from "../components/DashboardLayout";
import { Plus } from "lucide-react";

const sales = [
  { id: 1, date: "06/04/2026", client: "Maria Silva", product: "Kit Toalhas Batizado", quantity: 1, price: 120.00 },
  { id: 2, date: "06/04/2026", client: "João Santos", product: "Quadro Vagonite", quantity: 1, price: 85.00 },
  { id: 3, date: "05/04/2026", client: "Ana Costa", product: "Kit Maternidade", quantity: 1, price: 180.00 },
];

export function VendasProdutos() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Vendas de Produtos
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Nova Venda
          </button>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Data</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Cliente</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Produto</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Qtd</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Valor</th>
              </tr>
            </thead>
            <tbody>
              {sales.map((sale) => (
                <tr key={sale.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4">{sale.date}</td>
                  <td className="py-3 px-4 font-bold">{sale.client}</td>
                  <td className="py-3 px-4">{sale.product}</td>
                  <td className="py-3 px-4 font-black text-blue-900">{sale.quantity}</td>
                  <td className="py-3 px-4 font-black text-green-600">R$ {sale.price.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
