import { DashboardLayout } from "../components/DashboardLayout";

const clientSales = [
  { name: "Maria Silva", orders: 8, total: 1240.00 },
  { name: "João Santos", orders: 5, total: 890.00 },
  { name: "Ana Costa", orders: 4, total: 650.00 },
];

export function VendasCliente() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Vendas por Cliente
        </h1>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Cliente</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Pedidos</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Total Gasto</th>
              </tr>
            </thead>
            <tbody>
              {clientSales.map((client, index) => (
                <tr key={index} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold">{client.name}</td>
                  <td className="py-3 px-4 text-blue-900 font-black">{client.orders}</td>
                  <td className="py-3 px-4 font-black text-green-600">R$ {client.total.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
