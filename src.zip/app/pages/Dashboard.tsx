import { DashboardLayout } from "../components/DashboardLayout";
import { Package, DollarSign, ShoppingCart, TrendingUp, AlertTriangle, Users } from "lucide-react";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

const stats = [
  {
    title: "Produtos em Estoque",
    value: "142",
    icon: Package,
    color: "bg-blue-500",
  },
  {
    title: "Pedidos Pendentes",
    value: "23",
    icon: ShoppingCart,
    color: "bg-orange-500",
  },
  {
    title: "Receita do Mês",
    value: "R$ 8.450,00",
    icon: DollarSign,
    color: "bg-green-500",
  },
  {
    title: "Alertas de Estoque",
    value: "7",
    icon: AlertTriangle,
    color: "bg-red-500",
  },
  {
    title: "Clientes Ativos",
    value: "89",
    icon: Users,
    color: "bg-purple-500",
  },
  {
    title: "Margem de Lucro",
    value: "42%",
    icon: TrendingUp,
    color: "bg-teal-500",
  },
];

const recentOrders = [
  { id: "#001", client: "Maria Silva", product: "Kit Toalhas Batizado", status: "Em Produção", date: "05/04/2026" },
  { id: "#002", client: "João Santos", product: "Uniforme Bordado", status: "Pendente", date: "05/04/2026" },
  { id: "#003", client: "Ana Costa", product: "Quadro Vagonite", status: "Finalizado", date: "04/04/2026" },
  { id: "#004", client: "Pedro Oliveira", product: "Kit Maternidade", status: "Em Produção", date: "03/04/2026" },
  { id: "#005", client: "Carla Mendes", product: "Toalha de Mesa", status: "Entregue", date: "02/04/2026" },
];

const salesTrend = [
  { name: "Jan", vendas: 45 },
  { name: "Fev", vendas: 52 },
  { name: "Mar", vendas: 61 },
  { name: "Abr", vendas: 23 },
];

const productCategories = [
  { name: "Kits Batizado", value: 35, color: "#1e3a8a" },
  { name: "Uniformes", value: 25, color: "#f97316" },
  { name: "Quadros", value: 20, color: "#16a34a" },
  { name: "Maternidade", value: 15, color: "#9333ea" },
  { name: "Outros", value: 5, color: "#64748b" },
];

export function Dashboard() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Dashboard
        </h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
                    {stat.title}
                  </p>
                  <p className="text-2xl font-black text-blue-950">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-4 rounded-xl`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-white border rounded-2xl p-6">
            <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
              Tendência de Vendas
            </h2>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={salesTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="vendas"
                  stroke="#1e3a8a"
                  strokeWidth={3}
                  name="Vendas"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white border rounded-2xl p-6">
            <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
              Produtos Mais Vendidos
            </h2>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={productCategories}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {productCategories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
            Pedidos Recentes
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">ID</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Cliente</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Produto</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Status</th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Data</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((order) => (
                  <tr key={order.id} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold text-blue-900">{order.id}</td>
                    <td className="py-3 px-4">{order.client}</td>
                    <td className="py-3 px-4">{order.product}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                          order.status === "Entregue"
                            ? "bg-green-100 text-green-800"
                            : order.status === "Em Produção"
                            ? "bg-blue-100 text-blue-800"
                            : order.status === "Finalizado"
                            ? "bg-purple-100 text-purple-800"
                            : "bg-orange-100 text-orange-800"
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{order.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}