import { DashboardLayout } from "../components/DashboardLayout";
import { ShoppingCart, Clock, CheckCircle, TrendingUp, Plus, X } from "lucide-react";
import { useState } from "react";

export function Vendas() {
  const [showNewSaleForm, setShowNewSaleForm] = useState(false);
  const [formData, setFormData] = useState({
    client: "",
    product: "",
    quantity: 1,
    unitPrice: 0,
    paymentMethod: "",
    status: "Pendente",
    notes: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Nova venda:", formData);
    alert("Venda cadastrada com sucesso!");
    setShowNewSaleForm(false);
    setFormData({
      client: "",
      product: "",
      quantity: 1,
      unitPrice: 0,
      paymentMethod: "",
      status: "Pendente",
      notes: "",
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: name === "quantity" || name === "unitPrice" ? Number(value) : value,
    });
  };

  const totalValue = formData.quantity * formData.unitPrice;

  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Vendas e Encomendas
          </h1>
          <button
            onClick={() => setShowNewSaleForm(!showNewSaleForm)}
            className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2"
          >
            {showNewSaleForm ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
            {showNewSaleForm ? "Cancelar" : "Nova Venda"}
          </button>
        </div>

        {showNewSaleForm && (
          <div className="bg-white border rounded-2xl p-6 mb-8">
            <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950 mb-6">
              Cadastrar Nova Venda
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    Cliente *
                  </label>
                  <select
                    name="client"
                    value={formData.client}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  >
                    <option value="">Selecione um cliente</option>
                    <option value="Maria Silva">Maria Silva</option>
                    <option value="João Santos">João Santos</option>
                    <option value="Ana Costa">Ana Costa</option>
                    <option value="Pedro Oliveira">Pedro Oliveira</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    Produto *
                  </label>
                  <select
                    name="product"
                    value={formData.product}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  >
                    <option value="">Selecione um produto</option>
                    <option value="Kit Toalhas Batizado">Kit Toalhas Batizado</option>
                    <option value="Uniforme Bordado">Uniforme Bordado</option>
                    <option value="Quadro Vagonite">Quadro Vagonite</option>
                    <option value="Kit Maternidade">Kit Maternidade</option>
                    <option value="Toalha de Mesa">Toalha de Mesa</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    Quantidade *
                  </label>
                  <input
                    type="number"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleChange}
                    min="1"
                    required
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    Preço Unitário (R$) *
                  </label>
                  <input
                    type="number"
                    name="unitPrice"
                    value={formData.unitPrice}
                    onChange={handleChange}
                    min="0"
                    step="0.01"
                    required
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>

                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    Forma de Pagamento *
                  </label>
                  <select
                    name="paymentMethod"
                    value={formData.paymentMethod}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  >
                    <option value="">Selecione</option>
                    <option value="Dinheiro">Dinheiro</option>
                    <option value="PIX">PIX</option>
                    <option value="Cartão Débito">Cartão Débito</option>
                    <option value="Cartão Crédito">Cartão Crédito</option>
                    <option value="Parcelado">Parcelado</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                    Status *
                  </label>
                  <select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  >
                    <option value="Pendente">Pendente</option>
                    <option value="Em Produção">Em Produção</option>
                    <option value="Finalizado">Finalizado</option>
                    <option value="Entregue">Entregue</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold uppercase mb-2 text-gray-700">
                  Observações
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  rows={3}
                  className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900 resize-none"
                  placeholder="Detalhes adicionais da venda..."
                ></textarea>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-bold uppercase text-blue-900">Valor Total:</span>
                  <span className="text-2xl font-black text-blue-900">
                    R$ {totalValue.toFixed(2)}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-blue-900 text-white px-6 py-4 rounded-lg font-bold uppercase hover:bg-blue-800 transition-colors"
              >
                Cadastrar Venda
              </button>
            </form>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <ShoppingCart className="w-8 h-8 text-blue-900 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Total de Pedidos</p>
            <p className="text-3xl font-black text-blue-950">23</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Clock className="w-8 h-8 text-orange-500 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Em Produção</p>
            <p className="text-3xl font-black text-orange-500">8</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <CheckCircle className="w-8 h-8 text-green-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Finalizados</p>
            <p className="text-3xl font-black text-green-600">12</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <TrendingUp className="w-8 h-8 text-purple-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">Receita Pendente</p>
            <p className="text-2xl font-black text-purple-600">R$ 2.340</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white border rounded-2xl p-6">
            <h2 className="text-lg font-black uppercase mb-4">Pedidos Recentes</h2>
            <div className="space-y-3">
              {[
                { id: "#001", client: "Maria Silva", status: "Em Produção" },
                { id: "#002", client: "João Santos", status: "Pendente" },
                { id: "#003", client: "Ana Costa", status: "Finalizado" },
              ].map((order) => (
                <div key={order.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                  <div>
                    <p className="font-bold">{order.id}</p>
                    <p className="text-sm text-gray-600">{order.client}</p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                    order.status === "Finalizado" ? "bg-green-100 text-green-800" :
                    order.status === "Em Produção" ? "bg-blue-100 text-blue-800" :
                    "bg-orange-100 text-orange-800"
                  }`}>
                    {order.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border rounded-2xl p-6">
            <h2 className="text-lg font-black uppercase mb-4">Pagamentos Parciais</h2>
            <div className="space-y-3">
              {[
                { client: "João Santos", paid: 32.50, total: 65.00 },
                { client: "Carla Mendes", paid: 90.00, total: 180.00 },
              ].map((payment, index) => (
                <div key={index} className="p-3 bg-slate-50 rounded-lg">
                  <p className="font-bold mb-2">{payment.client}</p>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Pago: R$ {payment.paid.toFixed(2)}</span>
                    <span className="font-bold">Total: R$ {payment.total.toFixed(2)}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div
                      className="bg-green-600 h-2 rounded-full"
                      style={{ width: `${(payment.paid / payment.total) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}