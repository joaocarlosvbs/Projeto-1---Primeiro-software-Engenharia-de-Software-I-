import { DashboardLayout } from "../components/DashboardLayout";
import { Calculator, Plus } from "lucide-react";
import { useState } from "react";

export function CalculoPreco() {
  const [material, setMaterial] = useState(50);
  const [laborHours, setLaborHours] = useState(2);
  const [hourlyRate, setHourlyRate] = useState(25);
  const [margin, setMargin] = useState(45);

  const laborCost = laborHours * hourlyRate;
  const totalCost = material + laborCost;
  const salePrice = totalCost / (1 - margin / 100);

  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Cálculo de Preço (Mão de Obra)
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Calculator className="w-6 h-6 text-blue-900" />
              <h2 className="text-xl font-black uppercase">Calculadora de Preços</h2>
            </div>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold uppercase mb-2">Custo de Material (R$)</label>
                <input
                  type="number"
                  value={material}
                  onChange={(e) => setMaterial(Number(e.target.value))}
                  className="w-full px-4 py-3 border rounded-lg font-bold text-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
              </div>

              <div>
                <label className="block text-sm font-bold uppercase mb-2">Horas de Trabalho</label>
                <input
                  type="number"
                  value={laborHours}
                  onChange={(e) => setLaborHours(Number(e.target.value))}
                  className="w-full px-4 py-3 border rounded-lg font-bold text-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
              </div>

              <div>
                <label className="block text-sm font-bold uppercase mb-2">Valor Hora (R$)</label>
                <input
                  type="number"
                  value={hourlyRate}
                  onChange={(e) => setHourlyRate(Number(e.target.value))}
                  className="w-full px-4 py-3 border rounded-lg font-bold text-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
              </div>

              <div>
                <label className="block text-sm font-bold uppercase mb-2">Margem de Lucro (%)</label>
                <input
                  type="number"
                  value={margin}
                  onChange={(e) => setMargin(Number(e.target.value))}
                  className="w-full px-4 py-3 border rounded-lg font-bold text-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-6">
              <p className="text-sm uppercase tracking-wider text-blue-900 mb-2">Custo de Material</p>
              <p className="text-3xl font-black text-blue-900">R$ {material.toFixed(2)}</p>
            </div>

            <div className="bg-orange-50 border border-orange-200 rounded-2xl p-6">
              <p className="text-sm uppercase tracking-wider text-orange-900 mb-2">Custo de Mão de Obra</p>
              <p className="text-3xl font-black text-orange-900">R$ {laborCost.toFixed(2)}</p>
              <p className="text-sm text-orange-700 mt-2">{laborHours}h × R$ {hourlyRate}/h</p>
            </div>

            <div className="bg-purple-50 border border-purple-200 rounded-2xl p-6">
              <p className="text-sm uppercase tracking-wider text-purple-900 mb-2">Custo Total</p>
              <p className="text-3xl font-black text-purple-900">R$ {totalCost.toFixed(2)}</p>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-2xl p-6">
              <p className="text-sm uppercase tracking-wider text-green-900 mb-2">Preço de Venda Sugerido</p>
              <p className="text-4xl font-black text-green-900">R$ {salePrice.toFixed(2)}</p>
              <p className="text-sm text-green-700 mt-2">Margem: {margin}%</p>
            </div>

            <button className="w-full bg-blue-900 text-white px-6 py-4 rounded-lg font-bold uppercase hover:bg-blue-800 transition-colors flex items-center justify-center gap-2">
              <Plus className="w-5 h-5" />
              Salvar Cálculo
            </button>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
