import { DashboardLayout } from "../components/DashboardLayout";

const topProducts = [
  { rank: 1, name: "Uniforme Bordado", sold: 42, revenue: 2730.00 },
  { rank: 2, name: "Quadro Vagonite", sold: 23, revenue: 1955.00 },
  { rank: 3, name: "Toalha de Mesa", sold: 18, revenue: 1710.00 },
  { rank: 4, name: "Kit Toalhas Batizado", sold: 15, revenue: 1800.00 },
  { rank: 5, name: "Kit Maternidade", sold: 12, revenue: 2160.00 },
];

export function ProdutosMaisVendidos() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Produtos Mais Vendidos
        </h1>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Ranking</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Produto</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Quantidade</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Receita Total</th>
              </tr>
            </thead>
            <tbody>
              {topProducts.map((product) => (
                <tr key={product.rank} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4">
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-white ${
                      product.rank === 1 ? 'bg-yellow-500' : product.rank === 2 ? 'bg-gray-400' : product.rank === 3 ? 'bg-orange-600' : 'bg-blue-900'
                    }`}>
                      {product.rank}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-bold">{product.name}</td>
                  <td className="py-3 px-4 font-black text-blue-900">{product.sold}</td>
                  <td className="py-3 px-4 font-black text-green-600">R$ {product.revenue.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
