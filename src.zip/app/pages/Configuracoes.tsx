import { DashboardLayout } from "../components/DashboardLayout";
import { Settings, Shield, FileCheck } from "lucide-react";
import { Link } from "react-router";

export function Configuracoes() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Configurações e Segurança
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link to="/configuracoes/usuarios">
            <div className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all cursor-pointer group">
              <Shield className="w-12 h-12 text-blue-900 mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="text-lg font-black uppercase text-blue-950 mb-2">
                Níveis de Usuário (RBAC)
              </h3>
              <p className="text-sm text-gray-600">
                Gerencie permissões de acesso: Admin e Normal
              </p>
            </div>
          </Link>

          <Link to="/configuracoes/logs">
            <div className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all cursor-pointer group">
              <FileCheck className="w-12 h-12 text-purple-600 mb-4 group-hover:scale-110 transition-transform" />
              <h3 className="text-lg font-black uppercase text-blue-950 mb-2">
                Logs do Sistema
              </h3>
              <p className="text-sm text-gray-600">
                Visualize registro de atividades e segurança
              </p>
            </div>
          </Link>
        </div>
      </div>
    </DashboardLayout>
  );
}
