import { DashboardLayout } from "../components/DashboardLayout";
import { Plus, Search, Edit, Trash2, Package } from "lucide-react";

const products = [
  { id: 1, name: "Kit Toalhas Batizado Personalizadas", quantity: 2, category: "Kits", price: 120.00, cost: 65.00 },
  { id: 2, name: "Quadro Decorativo Vagonite 30x40", quantity: 1, category: "Decoração", price: 85.00, cost: 45.00 },
  { id: 3, name: "Toalha de Mesa Bordada 1,40x2,00", quantity: 8, category: "Mesa", price: 95.00, cost: 52.00 },
  { id: 4, name: "Kit Maternidade Completo", quantity: 5, category: "Kits", price: 180.00, cost: 95.00 },
  { id: 5, name: "Jogo de Toalhas Banho Bordadas", quantity: 12, category: "Banho", price: 78.00, cost: 42.00 },
  { id: 6, name: "Camisa Polo Bordada (Logo Empresa)", quantity: 25, category: "Uniformes", price: 65.00, cost: 35.00 },
  { id: 7, name: "Toalha de Rosto Personalizada", quantity: 18, category: "Banho", price: 32.00, cost: 18.00 },
  { id: 8, name: "Quadro Vagonite 20x30 Infantil", quantity: 3, category: "Decoração", price: 65.00, cost: 35.00 },
];

export function ProdutosAcabados() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Produtos Acabados
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Produto
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <Package className="w-8 h-8 text-blue-900 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Total de Produtos
            </p>
            <p className="text-3xl font-black text-blue-950">74</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Package className="w-8 h-8 text-green-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Disponíveis
            </p>
            <p className="text-3xl font-black text-green-600">74</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Package className="w-8 h-8 text-orange-500 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Estoque Baixo
            </p>
            <p className="text-3xl font-black text-orange-500">3</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Package className="w-8 h-8 text-purple-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Valor Total
            </p>
            <p className="text-2xl font-black text-purple-600">R$ 6.842</p>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar produtos acabados..."
              className="w-full pl-12 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
            />
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    ID
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Produto
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Categoria
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Quantidade
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Custo
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Preço Venda
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Margem
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {products.map((product) => {
                  const margin = ((product.price - product.cost) / product.price * 100).toFixed(0);
                  return (
                    <tr key={product.id} className="border-b hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-4 font-bold text-blue-900">
                        #{product.id.toString().padStart(3, '0')}
                      </td>
                      <td className="py-3 px-4 font-bold">{product.name}</td>
                      <td className="py-3 px-4">
                        <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-blue-100 text-blue-800">
                          {product.category}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`font-black ${product.quantity < 5 ? 'text-red-600' : 'text-green-600'}`}>
                          {product.quantity} unid
                        </span>
                      </td>
                      <td className="py-3 px-4 text-gray-600">
                        R$ {product.cost.toFixed(2)}
                      </td>
                      <td className="py-3 px-4 font-bold text-blue-900">
                        R$ {product.price.toFixed(2)}
                      </td>
                      <td className="py-3 px-4">
                        <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-green-100 text-green-800">
                          {margin}%
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex gap-2">
                          <button className="p-2 hover:bg-blue-50 rounded transition-colors">
                            <Edit className="w-4 h-4 text-blue-900" />
                          </button>
                          <button className="p-2 hover:bg-red-50 rounded transition-colors">
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
