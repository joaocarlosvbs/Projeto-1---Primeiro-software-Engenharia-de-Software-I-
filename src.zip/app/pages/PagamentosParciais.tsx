import { DashboardLayout } from "../components/DashboardLayout";
import { CreditCard } from "lucide-react";

const partialPayments = [
  { id: "#002", client: "João Santos", product: "Uniforme Bordado", total: 65.00, paid: 32.50, remaining: 32.50, date: "05/04/2026" },
  { id: "#004", client: "Pedro Oliveira", product: "Kit Maternidade", total: 180.00, paid: 90.00, remaining: 90.00, date: "03/04/2026" },
  { id: "#007", client: "Lucia Ferreira", product: "Kit Toalhas", total: 120.00, paid: 60.00, remaining: 60.00, date: "01/04/2026" },
];

export function PagamentosParciais() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Pagamentos Parciais (Sinal)
        </h1>

        <div className="bg-white border rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <CreditCard className="w-6 h-6 text-blue-900" />
            <h2 className="text-xl font-black uppercase">Pedidos com Entrada</h2>
          </div>

          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">ID</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Cliente</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Produto</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Valor Total</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Pago</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Restante</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Progresso</th>
              </tr>
            </thead>
            <tbody>
              {partialPayments.map((payment) => {
                const percentage = (payment.paid / payment.total) * 100;
                return (
                  <tr key={payment.id} className="border-b hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold text-blue-900">{payment.id}</td>
                    <td className="py-3 px-4 font-bold">{payment.client}</td>
                    <td className="py-3 px-4">{payment.product}</td>
                    <td className="py-3 px-4 font-black text-blue-900">R$ {payment.total.toFixed(2)}</td>
                    <td className="py-3 px-4 font-black text-green-600">R$ {payment.paid.toFixed(2)}</td>
                    <td className="py-3 px-4 font-black text-orange-600">R$ {payment.remaining.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-green-600 h-2 rounded-full"
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                        <span className="text-xs font-bold whitespace-nowrap">{percentage.toFixed(0)}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
