import { DashboardLayout } from "../components/DashboardLayout";
import { TrendingUp, ShoppingBag, ShoppingCart, PackageX } from "lucide-react";

export function Movimentacoes() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Movimentações
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all">
            <ShoppingBag className="w-12 h-12 text-blue-900 mb-4" />
            <h3 className="text-lg font-black uppercase text-blue-950 mb-2">
              Compras de Produtos
            </h3>
            <p className="text-3xl font-black text-blue-900 mb-2">15</p>
            <p className="text-sm text-gray-600">Movimentações este mês</p>
          </div>

          <div className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all">
            <ShoppingCart className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-lg font-black uppercase text-blue-950 mb-2">
              Vendas de Produtos
            </h3>
            <p className="text-3xl font-black text-green-600 mb-2">23</p>
            <p className="text-sm text-gray-600">Movimentações este mês</p>
          </div>

          <div className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all">
            <PackageX className="w-12 h-12 text-red-600 mb-4" />
            <h3 className="text-lg font-black uppercase text-blue-950 mb-2">
              Devolução de Produtos
            </h3>
            <p className="text-3xl font-black text-red-600 mb-2">2</p>
            <p className="text-sm text-gray-600">Movimentações este mês</p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
