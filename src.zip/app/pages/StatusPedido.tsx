import { DashboardLayout } from "../components/DashboardLayout";
import { ClipboardList } from "lucide-react";

const orders = [
  { id: "#001", client: "Maria Silva", product: "Kit Toalhas Batizado", date: "05/04/2026", status: "Em Produção", deadline: "15/04/2026" },
  { id: "#002", client: "João Santos", product: "Uniforme Bordado", date: "05/04/2026", status: "Pendente", deadline: "20/04/2026" },
  { id: "#003", client: "Ana Costa", product: "Quadro Vagonite", date: "04/04/2026", status: "Finalizado", deadline: "10/04/2026" },
  { id: "#004", client: "Pedro Oliveira", product: "Kit Maternidade", date: "03/04/2026", status: "Em Produção", deadline: "18/04/2026" },
  { id: "#005", client: "Carla Mendes", product: "Toalha de Mesa", date: "02/04/2026", status: "Entregue", deadline: "12/04/2026" },
];

export function StatusPedido() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Status do Pedido (Produção)
        </h1>

        <div className="bg-white border rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <ClipboardList className="w-6 h-6 text-blue-900" />
            <h2 className="text-xl font-black uppercase">Acompanhamento de Pedidos</h2>
          </div>

          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">ID</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Cliente</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Produto</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Data Pedido</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Prazo</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Status</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold text-blue-900">{order.id}</td>
                  <td className="py-3 px-4 font-bold">{order.client}</td>
                  <td className="py-3 px-4">{order.product}</td>
                  <td className="py-3 px-4 text-gray-600">{order.date}</td>
                  <td className="py-3 px-4 text-gray-600">{order.deadline}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                      order.status === "Entregue" ? "bg-green-100 text-green-800" :
                      order.status === "Em Produção" ? "bg-blue-100 text-blue-800" :
                      order.status === "Finalizado" ? "bg-purple-100 text-purple-800" :
                      "bg-orange-100 text-orange-800"
                    }`}>
                      {order.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
