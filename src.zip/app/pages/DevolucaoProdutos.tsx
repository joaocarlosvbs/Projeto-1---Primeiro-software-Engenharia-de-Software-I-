import { DashboardLayout } from "../components/DashboardLayout";

const returns = [
  { id: 1, date: "04/04/2026", client: "Cliente X", product: "Quadro Vagonite", reason: "Defeito de fabricação", value: 85.00, status: "Processada" },
  { id: 2, date: "28/03/2026", client: "Cliente Y", product: "Toalha Mesa", reason: "Tamanho incorreto", value: 95.00, status: "Processada" },
];

export function DevolucaoProdutos() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Devolução de Produtos
        </h1>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Data</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Cliente</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Produto</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Motivo</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Valor</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Status</th>
              </tr>
            </thead>
            <tbody>
              {returns.map((returnItem) => (
                <tr key={returnItem.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4">{returnItem.date}</td>
                  <td className="py-3 px-4 font-bold">{returnItem.client}</td>
                  <td className="py-3 px-4">{returnItem.product}</td>
                  <td className="py-3 px-4 text-gray-600">{returnItem.reason}</td>
                  <td className="py-3 px-4 font-black text-red-600">R$ {returnItem.value.toFixed(2)}</td>
                  <td className="py-3 px-4">
                    <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-blue-100 text-blue-800">
                      {returnItem.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
