import { Navbar } from "../components/Navbar";
import { Wand2, Shirt, Palette, Package, ShoppingCart, TrendingUp, Heart, Baby, Utensils } from "lucide-react";

const portfolio = [
  { title: "Kit Toalhas Batizado Personalizadas", price: "A partir de R$ 120,00", icon: Baby, category: "Kits" },
  { title: "Uniformes Bordados (Logo Empresa)", price: "Sob Orçamento", icon: Shirt, category: "Uniformes" },
  { title: "Quadros Decorativos Vagonite", price: "R$ 85,00", icon: Palette, category: "Decoração" },
  { title: "Kit Maternidade Completo", price: "R$ 180,00", icon: Heart, category: "Kits" },
  { title: "Toalhas de Mesa Bordadas", price: "A partir de R$ 95,00", icon: Utensils, category: "Mesa" },
  { title: "Bordados Personalizados", price: "A partir de R$ 45,00", icon: Package, category: "Diversos" },
  { title: "Jogo de Toalhas Banho", price: "R$ 78,00", icon: Wand2, category: "Banho" },
  { title: "Toalha de Rosto Personalizada", price: "R$ 32,00", icon: ShoppingCart, category: "Banho" },
  { title: "Quadro Infantil 20x30", price: "R$ 65,00", icon: TrendingUp, category: "Decoração" },
];

export function Portfolio() {
  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      <main className="p-10">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-black text-center mb-4 uppercase tracking-tighter text-blue-950">
            Portfólio de Serviços
          </h2>
          <p className="text-center text-gray-600 mb-12">
            Confira nossa linha completa de produtos bordados e personalizados
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {portfolio.map((item, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="h-64 bg-slate-100 rounded-3xl mb-4 flex flex-col items-center justify-center text-slate-300 group-hover:bg-blue-50 transition-all p-6">
                  <item.icon className="w-16 h-16 mb-4" strokeWidth={1.5} />
                  <span className="text-xs uppercase tracking-wider text-gray-500 group-hover:text-blue-900 transition-colors">
                    {item.category}
                  </span>
                </div>
                <h4 className="font-bold text-center text-sm uppercase mb-1">
                  {item.title}
                </h4>
                <p className="text-center text-blue-900 font-black">
                  {item.price}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-blue-50 border border-blue-200 rounded-3xl p-8 text-center">
            <h3 className="text-2xl font-black uppercase text-blue-950 mb-4">
              Faça seu Orçamento
            </h3>
            <p className="text-gray-700 mb-6">
              Entre em contato conosco para criar seu bordado personalizado
            </p>
            <button className="bg-blue-900 text-white px-8 py-4 rounded-lg font-bold uppercase hover:bg-blue-800 transition-colors">
              Solicitar Orçamento
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
