import { DashboardLayout } from "../components/DashboardLayout";
import { Package, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";

const stockData = [
  { category: "Matéria-prima", total: 245, min: 50, icon: Package, trend: "up" },
  { category: "Produtos Acabados", total: 142, min: 20, icon: Package, trend: "down" },
  { category: "Produtos em Produção", total: 18, min: 0, icon: TrendingUp, trend: "up" },
  { category: "Alertas Críticos", total: 7, min: 0, icon: AlertTriangle, trend: "down" },
];

const lowStockItems = [
  { name: "Linha Branca 100m", quantity: 12, min: 50, category: "Matéria-prima" },
  { name: "Tecido Algodão Azul", quantity: 5, min: 20, category: "Matéria-prima" },
  { name: "Bastidores 15cm", quantity: 3, min: 10, category: "Matéria-prima" },
  { name: "Kit Toalhas Batizado", quantity: 2, min: 5, category: "Produto Acabado" },
  { name: "Quadros Vagonite 30x40", quantity: 1, min: 3, category: "Produto Acabado" },
];

export function Estoque() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Produção e Estoque
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {stockData.map((item, index) => (
            <div key={index} className="bg-white border rounded-2xl p-6 hover:shadow-lg transition-all">
              <div className="flex items-center justify-between mb-4">
                <item.icon className="w-8 h-8 text-blue-900" />
                {item.trend === "up" ? (
                  <TrendingUp className="w-5 h-5 text-green-500" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-red-500" />
                )}
              </div>
              <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
                {item.category}
              </p>
              <p className="text-3xl font-black text-blue-950">{item.total}</p>
              {item.min > 0 && (
                <p className="text-xs text-gray-500 mt-2">
                  Mínimo: {item.min}
                </p>
              )}
            </div>
          ))}
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <AlertTriangle className="w-6 h-6 text-orange-500" />
            <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950">
              Itens com Estoque Baixo
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Item
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Categoria
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Quantidade Atual
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Estoque Mínimo
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody>
                {lowStockItems.map((item, index) => (
                  <tr key={index} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold">{item.name}</td>
                    <td className="py-3 px-4 text-gray-600">{item.category}</td>
                    <td className="py-3 px-4">
                      <span className="font-black text-red-600">{item.quantity}</span>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{item.min}</td>
                    <td className="py-3 px-4">
                      <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-red-100 text-red-800">
                        Crítico
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button className="mt-6 bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors">
            Solicitar Reposição
          </button>
        </div>
      </div>
    </DashboardLayout>
  );
}
