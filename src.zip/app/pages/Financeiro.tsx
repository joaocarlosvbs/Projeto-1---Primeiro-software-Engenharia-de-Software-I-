import { DashboardLayout } from "../components/DashboardLayout";
import { DollarSign, TrendingUp, TrendingDown, Wallet, CreditCard, Percent } from "lucide-react";

export function Financeiro() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Financeiro
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <DollarSign className="w-8 h-8 text-green-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Receita do Mês
            </p>
            <p className="text-3xl font-black text-green-600">R$ 8.450,00</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <TrendingDown className="w-8 h-8 text-red-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Despesas do Mês
            </p>
            <p className="text-3xl font-black text-red-600">R$ 3.290,00</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Wallet className="w-8 h-8 text-blue-900 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Lucro Líquido
            </p>
            <p className="text-3xl font-black text-blue-900">R$ 5.160,00</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="w-6 h-6 text-green-600" />
              <h2 className="text-lg font-black uppercase">Recebimentos Pendentes</h2>
            </div>
            <p className="text-2xl font-black text-green-600 mb-2">R$ 2.340,00</p>
            <p className="text-sm text-gray-600">12 recebimentos aguardando</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <CreditCard className="w-6 h-6 text-orange-500" />
              <h2 className="text-lg font-black uppercase">Pagamentos Pendentes</h2>
            </div>
            <p className="text-2xl font-black text-orange-500 mb-2">R$ 890,00</p>
            <p className="text-sm text-gray-600">5 fornecedores a pagar</p>
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <Percent className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-black uppercase tracking-tighter text-blue-950">
              Margem de Lucro por Produto
            </h2>
          </div>
          <div className="space-y-4">
            {[
              { name: "Kit Toalhas Batizado", margin: 46 },
              { name: "Uniformes Bordados", margin: 46 },
              { name: "Quadro Vagonite", margin: 47 },
              { name: "Kit Maternidade", margin: 47 },
              { name: "Toalha de Mesa", margin: 45 },
            ].map((product, index) => (
              <div key={index}>
                <div className="flex justify-between mb-2">
                  <span className="font-bold">{product.name}</span>
                  <span className="font-black text-purple-600">{product.margin}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-purple-600 h-2 rounded-full"
                    style={{ width: `${product.margin}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
