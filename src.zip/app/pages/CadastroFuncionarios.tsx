import { DashboardLayout } from "../components/DashboardLayout";
import { Plus } from "lucide-react";

const employees = [
  { id: 1, name: "Cleonice Maria da Silva", role: "Proprietária / Artesã", phone: "(16) 99999-0000" },
  { id: 2, name: "Auxiliar 1", role: "Auxiliar de Produção", phone: "(16) 98888-1111" },
  { id: 3, name: "Auxiliar 2", role: "Auxiliar de Vendas", phone: "(16) 97777-2222" },
];

export function CadastroFuncionarios() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Cadastro de Funcionários
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Funcionário
          </button>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">ID</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Nome</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Função</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase text-gray-500">Telefone</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((employee) => (
                <tr key={employee.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold text-blue-900">#{employee.id.toString().padStart(3, '0')}</td>
                  <td className="py-3 px-4 font-bold">{employee.name}</td>
                  <td className="py-3 px-4">{employee.role}</td>
                  <td className="py-3 px-4 text-gray-600">{employee.phone}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
