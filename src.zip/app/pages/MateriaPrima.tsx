import { DashboardLayout } from "../components/DashboardLayout";
import { Plus, Search, Edit, Trash2 } from "lucide-react";

const materials = [
  { id: 1, name: "Linha Branca 100m", quantity: 12, unit: "unid", min: 50, max: 200, supplier: "Fios & Cia", cost: 8.50 },
  { id: 2, name: "Linha Preta 100m", quantity: 45, unit: "unid", min: 50, max: 200, supplier: "Fios & Cia", cost: 8.50 },
  { id: 3, name: "Linha Azul Marinho 100m", quantity: 32, unit: "unid", min: 30, max: 150, supplier: "Fios & Cia", cost: 9.00 },
  { id: 4, name: "Tecido Algodão Branco", quantity: 5, unit: "m", min: 20, max: 100, supplier: "Tecidos Premium", cost: 25.00 },
  { id: 5, name: "Tecido Algodão Azul", quantity: 8, unit: "m", min: 20, max: 100, supplier: "Tecidos Premium", cost: 27.00 },
  { id: 6, name: "Bastidores 15cm", quantity: 3, unit: "unid", min: 10, max: 50, supplier: "Armarinho Central", cost: 12.00 },
  { id: 7, name: "Bastidores 20cm", quantity: 15, unit: "unid", min: 10, max: 50, supplier: "Armarinho Central", cost: 15.00 },
  { id: 8, name: "Entretela Termocolante", quantity: 25, unit: "m", min: 15, max: 80, supplier: "Tecidos Premium", cost: 8.00 },
];

export function MateriaPrima() {
  return (
    <DashboardLayout>
      <div>
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950">
            Matéria-Prima (Insumos)
          </h1>
          <button className="bg-blue-900 text-white px-6 py-3 rounded-lg font-bold uppercase text-sm hover:bg-blue-800 transition-colors flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Novo Insumo
          </button>
        </div>

        <div className="bg-white border rounded-2xl p-6 mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar insumos..."
              className="w-full pl-12 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
            />
          </div>
        </div>

        <div className="bg-white border rounded-2xl p-6">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    ID
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Descrição
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Quantidade
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Estoque Min/Max
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Fornecedor
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Custo Unit.
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody>
                {materials.map((material) => (
                  <tr key={material.id} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold text-blue-900">#{material.id.toString().padStart(3, '0')}</td>
                    <td className="py-3 px-4 font-bold">{material.name}</td>
                    <td className="py-3 px-4">
                      <span className={`font-black ${material.quantity < material.min ? 'text-red-600' : 'text-green-600'}`}>
                        {material.quantity} {material.unit}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-600">
                      {material.min} / {material.max} {material.unit}
                    </td>
                    <td className="py-3 px-4 text-gray-600">{material.supplier}</td>
                    <td className="py-3 px-4 font-bold text-blue-900">
                      R$ {material.cost.toFixed(2)}
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button className="p-2 hover:bg-blue-50 rounded transition-colors">
                          <Edit className="w-4 h-4 text-blue-900" />
                        </button>
                        <button className="p-2 hover:bg-red-50 rounded transition-colors">
                          <Trash2 className="w-4 h-4 text-red-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
