import { DashboardLayout } from "../components/DashboardLayout";
import { AlertTriangle, Bell, Package } from "lucide-react";

const alerts = [
  { id: 1, item: "Linha Branca 100m", type: "Matéria-prima", current: 12, min: 50, severity: "critical" },
  { id: 2, item: "Tecido Algodão Azul", type: "Matéria-prima", current: 5, min: 20, severity: "critical" },
  { id: 3, item: "Bastidores 15cm", type: "Matéria-prima", current: 3, min: 10, severity: "critical" },
  { id: 4, item: "Kit Toalhas Batizado", type: "Produto Acabado", current: 2, min: 5, severity: "critical" },
  { id: 5, item: "Quadro Vagonite 30x40", type: "Produto Acabado", current: 1, min: 3, severity: "critical" },
  { id: 6, item: "Linha Azul Marinho", type: "Matéria-prima", current: 32, min: 30, severity: "warning" },
  { id: 7, item: "Quadro Vagonite 20x30", type: "Produto Acabado", current: 3, min: 5, severity: "warning" },
];

export function AlertasEstoque() {
  const criticalAlerts = alerts.filter(a => a.severity === "critical");
  const warningAlerts = alerts.filter(a => a.severity === "warning");

  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Alertas de Estoque
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white border rounded-2xl p-6">
            <AlertTriangle className="w-8 h-8 text-red-600 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Alertas Críticos
            </p>
            <p className="text-3xl font-black text-red-600">{criticalAlerts.length}</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Bell className="w-8 h-8 text-orange-500 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Avisos
            </p>
            <p className="text-3xl font-black text-orange-500">{warningAlerts.length}</p>
          </div>
          <div className="bg-white border rounded-2xl p-6">
            <Package className="w-8 h-8 text-blue-900 mb-3" />
            <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">
              Total de Itens
            </p>
            <p className="text-3xl font-black text-blue-950">{alerts.length}</p>
          </div>
        </div>

        <div className="bg-red-50 border border-red-200 rounded-2xl p-6 mb-6">
          <div className="flex items-center gap-3 mb-6">
            <AlertTriangle className="w-6 h-6 text-red-600" />
            <h2 className="text-xl font-black uppercase tracking-tighter text-red-900">
              Alertas Críticos ({criticalAlerts.length})
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-lg">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Item
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Tipo
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Quantidade Atual
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Estoque Mínimo
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Ação
                  </th>
                </tr>
              </thead>
              <tbody>
                {criticalAlerts.map((alert) => (
                  <tr key={alert.id} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold">{alert.item}</td>
                    <td className="py-3 px-4 text-gray-600">{alert.type}</td>
                    <td className="py-3 px-4">
                      <span className="font-black text-red-600">{alert.current}</span>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{alert.min}</td>
                    <td className="py-3 px-4">
                      <button className="bg-blue-900 text-white px-4 py-2 rounded-lg font-bold text-xs uppercase hover:bg-blue-800">
                        Solicitar Reposição
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-orange-50 border border-orange-200 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-6">
            <Bell className="w-6 h-6 text-orange-600" />
            <h2 className="text-xl font-black uppercase tracking-tighter text-orange-900">
              Avisos ({warningAlerts.length})
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full bg-white rounded-lg">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Item
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Tipo
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Quantidade Atual
                  </th>
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">
                    Estoque Mínimo
                  </th>
                </tr>
              </thead>
              <tbody>
                {warningAlerts.map((alert) => (
                  <tr key={alert.id} className="border-b hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold">{alert.item}</td>
                    <td className="py-3 px-4 text-gray-600">{alert.type}</td>
                    <td className="py-3 px-4">
                      <span className="font-black text-orange-600">{alert.current}</span>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{alert.min}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
