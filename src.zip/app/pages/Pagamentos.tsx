import { DashboardLayout } from "../components/DashboardLayout";
import { Send } from "lucide-react";

const payments = [
  { id: 1, supplier: "Fios & Cia", description: "Linhas Bordado", value: 450.00, date: "15/04/2026", status: "pending" },
  { id: 2, supplier: "Tecidos Premium", description: "Tecidos Algodão", value: 280.00, date: "20/04/2026", status: "pending" },
  { id: 3, supplier: "Armarinho Central", description: "Bastidores e Acessórios", value: 160.00, date: "10/04/2026", status: "paid" },
];

export function Pagamentos() {
  return (
    <DashboardLayout>
      <div>
        <h1 className="text-3xl font-black uppercase tracking-tighter text-blue-950 mb-8">
          Pagamentos aos Fornecedores
        </h1>

        <div className="bg-white border rounded-2xl p-6">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Fornecedor</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Descrição</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Valor</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Vencimento</th>
                <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-gray-500">Status</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((payment) => (
                <tr key={payment.id} className="border-b hover:bg-slate-50">
                  <td className="py-3 px-4 font-bold">{payment.supplier}</td>
                  <td className="py-3 px-4">{payment.description}</td>
                  <td className="py-3 px-4 font-black text-red-600">R$ {payment.value.toFixed(2)}</td>
                  <td className="py-3 px-4">{payment.date}</td>
                  <td className="py-3 px-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${
                      payment.status === "paid" ? "bg-green-100 text-green-800" : "bg-orange-100 text-orange-800"
                    }`}>
                      {payment.status === "paid" ? "Pago" : "Pendente"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
