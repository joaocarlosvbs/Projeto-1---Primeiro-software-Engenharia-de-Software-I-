import { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { Sidebar } from "./Sidebar";

interface DashboardLayoutProps {
  children: ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-white">
      <Navbar isDashboard />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-10">{children}</main>
      </div>
    </div>
  );
}
