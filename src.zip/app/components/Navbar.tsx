import { Link } from "react-router";
import { LogIn } from "lucide-react";

interface NavbarProps {
  isDashboard?: boolean;
}

export function Navbar({ isDashboard = false }: NavbarProps) {
  return (
    <nav className="p-6 flex justify-between items-center border-b">
      <Link to="/">
        <h1 className="text-xl font-black text-blue-900 uppercase italic">
          Vitrine <span className="text-orange-500 font-light">Bordados</span>
        </h1>
      </Link>
      <div className="space-x-8 text-xs font-bold uppercase tracking-widest text-gray-500">
        {!isDashboard ? (
          <>
            <Link to="/" className="text-blue-900 hover:text-blue-900">
              Início
            </Link>
            <Link to="/vendas/portfolio" className="hover:text-blue-900">
              Produtos
            </Link>
            <Link to="/contato" className="hover:text-blue-900">
              Contato
            </Link>
            <Link 
              to="/login" 
              className="inline-flex items-center gap-2 px-4 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600 transition-colors normal-case tracking-normal"
            >
              <LogIn className="h-4 w-4" />
              Entrar
            </Link>
          </>
        ) : (
          <>
            <Link to="/dashboard" className="text-blue-900 hover:text-blue-900">
              Dashboard
            </Link>
            <Link to="/" className="hover:text-blue-900">
              Sair
            </Link>
          </>
        )}
      </div>
    </nav>
  );
}