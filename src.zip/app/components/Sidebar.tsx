import { Link, useLocation } from "react-router";
import {
  Package,
  DollarSign,
  BarChart3,
  Users,
  ShoppingCart,
  TrendingUp,
  Settings,
  Box,
  AlertTriangle,
  Wallet,
  Calculator,
  CreditCard,
  Send,
  TrendingDown,
  Calendar,
  FileText,
  Briefcase,
  PackageOpen,
  ClipboardList,
  Percent,
  ShoppingBag,
  PackageX,
  Shield,
  FileCheck,
  Mail,
  UserCog,
} from "lucide-react";

const menuItems = [
  {
    title: "Produção e Estoque",
    icon: Package,
    path: "/estoque",
    submenu: [
      { title: "Visão Geral", path: "/estoque", icon: Box },
      { title: "Matéria-prima", path: "/estoque/materia-prima", icon: Package },
      { title: "Produtos Acabados", path: "/estoque/produtos-acabados", icon: PackageOpen },
      { title: "Alertas de Estoque", path: "/estoque/alertas", icon: AlertTriangle },
    ],
  },
  {
    title: "Financeiro",
    icon: DollarSign,
    path: "/financeiro",
    submenu: [
      { title: "Visão Geral", path: "/financeiro", icon: Wallet },
      { title: "Fluxo de Caixa", path: "/financeiro/fluxo-caixa", icon: TrendingUp },
      { title: "Cálculo de Preço", path: "/financeiro/calculo-preco", icon: Calculator },
      { title: "Recebimentos", path: "/financeiro/recebimentos", icon: CreditCard },
      { title: "Pagamentos", path: "/financeiro/pagamentos", icon: Send },
      { title: "Margem de Lucro", path: "/financeiro/margem-lucro", icon: Percent },
    ],
  },
  {
    title: "Relatórios",
    icon: BarChart3,
    path: "/relatorios",
    submenu: [
      { title: "Visão Geral", path: "/relatorios", icon: FileText },
      { title: "Vendas por Período", path: "/relatorios/vendas-periodo", icon: Calendar },
      { title: "Lucro por Produto", path: "/relatorios/lucro-produto", icon: TrendingUp },
      { title: "Produtos Mais Vendidos", path: "/relatorios/produtos-vendidos", icon: TrendingDown },
      { title: "Vendas por Cliente", path: "/relatorios/vendas-cliente", icon: Users },
      { title: "Clientes Aniversariantes", path: "/relatorios/aniversariantes", icon: Calendar },
    ],
  },
  {
    title: "Cadastros",
    icon: Users,
    path: "/cadastros",
    submenu: [
      { title: "Visão Geral", path: "/cadastros", icon: ClipboardList },
      { title: "Clientes (LGPD)", path: "/cadastros/clientes", icon: Users },
      { title: "Fornecedores", path: "/cadastros/fornecedores", icon: Briefcase },
      { title: "Produtos", path: "/cadastros/produtos", icon: Package },
      { title: "Funcionários", path: "/cadastros/funcionarios", icon: UserCog },
      { title: "Tipos de Produtos", path: "/cadastros/tipos-produtos", icon: FileText },
    ],
  },
  {
    title: "Vendas e Encomendas",
    icon: ShoppingCart,
    path: "/vendas",
    submenu: [
      { title: "Visão Geral", path: "/vendas", icon: ShoppingCart },
      { title: "Status do Pedido", path: "/vendas/status-pedido", icon: ClipboardList },
      { title: "Portfólio de Serviços", path: "/vendas/portfolio", icon: FileText },
      { title: "Pagamentos Parciais", path: "/vendas/pagamentos-parciais", icon: CreditCard },
    ],
  },
  {
    title: "Movimentações",
    icon: TrendingUp,
    path: "/movimentacoes",
    submenu: [
      { title: "Visão Geral", path: "/movimentacoes", icon: TrendingUp },
      { title: "Compras de Produtos", path: "/movimentacoes/compras", icon: ShoppingBag },
      { title: "Vendas de Produtos", path: "/movimentacoes/vendas", icon: ShoppingCart },
      { title: "Devolução de Produtos", path: "/movimentacoes/devolucoes", icon: PackageX },
    ],
  },
  {
    title: "Configurações",
    icon: Settings,
    path: "/configuracoes",
    submenu: [
      { title: "Visão Geral", path: "/configuracoes", icon: Settings },
      { title: "Níveis de Usuário", path: "/configuracoes/usuarios", icon: Shield },
      { title: "Logs do Sistema", path: "/configuracoes/logs", icon: FileCheck },
    ],
  },
];

export function Sidebar() {
  const location = useLocation();

  return (
    <aside className="w-64 bg-slate-50 min-h-screen border-r p-6">
      <div className="space-y-6">
        {menuItems.map((item) => {
          const isActive = location.pathname.startsWith(item.path);
          return (
            <div key={item.path}>
              <Link to={item.path}>
                <div
                  className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                    isActive
                      ? "bg-blue-900 text-white"
                      : "text-gray-700 hover:bg-blue-50"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="text-sm font-bold uppercase tracking-wide">
                    {item.title}
                  </span>
                </div>
              </Link>
              {isActive && item.submenu && (
                <div className="ml-8 mt-2 space-y-1">
                  {item.submenu.map((subitem) => {
                    const isSubActive = location.pathname === subitem.path;
                    return (
                      <Link key={subitem.path} to={subitem.path}>
                        <div
                          className={`flex items-center gap-2 p-2 rounded text-xs transition-all ${
                            isSubActive
                              ? "text-orange-500 font-bold"
                              : "text-gray-600 hover:text-blue-900"
                          }`}
                        >
                          <subitem.icon className="w-4 h-4" />
                          <span>{subitem.title}</span>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
        <Link to="/contato">
          <div className="flex items-center gap-3 p-3 rounded-lg text-gray-700 hover:bg-blue-50 transition-all">
            <Mail className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-wide">
              Contato/Suporte
            </span>
          </div>
        </Link>
      </div>
    </aside>
  );
}
