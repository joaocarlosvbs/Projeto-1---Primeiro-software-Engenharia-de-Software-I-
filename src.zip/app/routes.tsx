import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { Login } from "./pages/Login";
import { ClientePedidos } from "./pages/ClientePedidos";
import { Dashboard } from "./pages/Dashboard";
import { Estoque } from "./pages/Estoque";
import { MateriaPrima } from "./pages/MateriaPrima";
import { ProdutosAcabados } from "./pages/ProdutosAcabados";
import { AlertasEstoque } from "./pages/AlertasEstoque";
import { Financeiro } from "./pages/Financeiro";
import { FluxoCaixa } from "./pages/FluxoCaixa";
import { CalculoPreco } from "./pages/CalculoPreco";
import { Recebimentos } from "./pages/Recebimentos";
import { Pagamentos } from "./pages/Pagamentos";
import { MargemLucro } from "./pages/MargemLucro";
import { Relatorios } from "./pages/Relatorios";
import { VendasPeriodo } from "./pages/VendasPeriodo";
import { LucroProduto } from "./pages/LucroProduto";
import { ProdutosMaisVendidos } from "./pages/ProdutosMaisVendidos";
import { VendasCliente } from "./pages/VendasCliente";
import { ClientesAniversariantes } from "./pages/ClientesAniversariantes";
import { Cadastros } from "./pages/Cadastros";
import { CadastroClientes } from "./pages/CadastroClientes";
import { CadastroFornecedores } from "./pages/CadastroFornecedores";
import { CadastroProdutos } from "./pages/CadastroProdutos";
import { CadastroFuncionarios } from "./pages/CadastroFuncionarios";
import { TiposProdutos } from "./pages/TiposProdutos";
import { Vendas } from "./pages/Vendas";
import { StatusPedido } from "./pages/StatusPedido";
import { Portfolio } from "./pages/Portfolio";
import { PagamentosParciais } from "./pages/PagamentosParciais";
import { Movimentacoes } from "./pages/Movimentacoes";
import { ComprasProdutos } from "./pages/ComprasProdutos";
import { VendasProdutos } from "./pages/VendasProdutos";
import { DevolucaoProdutos } from "./pages/DevolucaoProdutos";
import { Configuracoes } from "./pages/Configuracoes";
import { NiveisUsuario } from "./pages/NiveisUsuario";
import { LogsSistema } from "./pages/LogsSistema";
import { Contato } from "./pages/Contato";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/cliente/pedidos",
    Component: ClientePedidos,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
  {
    path: "/estoque",
    Component: Estoque,
  },
  {
    path: "/estoque/materia-prima",
    Component: MateriaPrima,
  },
  {
    path: "/estoque/produtos-acabados",
    Component: ProdutosAcabados,
  },
  {
    path: "/estoque/alertas",
    Component: AlertasEstoque,
  },
  {
    path: "/financeiro",
    Component: Financeiro,
  },
  {
    path: "/financeiro/fluxo-caixa",
    Component: FluxoCaixa,
  },
  {
    path: "/financeiro/calculo-preco",
    Component: CalculoPreco,
  },
  {
    path: "/financeiro/recebimentos",
    Component: Recebimentos,
  },
  {
    path: "/financeiro/pagamentos",
    Component: Pagamentos,
  },
  {
    path: "/financeiro/margem-lucro",
    Component: MargemLucro,
  },
  {
    path: "/relatorios",
    Component: Relatorios,
  },
  {
    path: "/relatorios/vendas-periodo",
    Component: VendasPeriodo,
  },
  {
    path: "/relatorios/lucro-produto",
    Component: LucroProduto,
  },
  {
    path: "/relatorios/produtos-vendidos",
    Component: ProdutosMaisVendidos,
  },
  {
    path: "/relatorios/vendas-cliente",
    Component: VendasCliente,
  },
  {
    path: "/relatorios/aniversariantes",
    Component: ClientesAniversariantes,
  },
  {
    path: "/cadastros",
    Component: Cadastros,
  },
  {
    path: "/cadastros/clientes",
    Component: CadastroClientes,
  },
  {
    path: "/cadastros/fornecedores",
    Component: CadastroFornecedores,
  },
  {
    path: "/cadastros/produtos",
    Component: CadastroProdutos,
  },
  {
    path: "/cadastros/funcionarios",
    Component: CadastroFuncionarios,
  },
  {
    path: "/cadastros/tipos-produtos",
    Component: TiposProdutos,
  },
  {
    path: "/vendas",
    Component: Vendas,
  },
  {
    path: "/vendas/status-pedido",
    Component: StatusPedido,
  },
  {
    path: "/vendas/portfolio",
    Component: Portfolio,
  },
  {
    path: "/vendas/pagamentos-parciais",
    Component: PagamentosParciais,
  },
  {
    path: "/movimentacoes",
    Component: Movimentacoes,
  },
  {
    path: "/movimentacoes/compras",
    Component: ComprasProdutos,
  },
  {
    path: "/movimentacoes/vendas",
    Component: VendasProdutos,
  },
  {
    path: "/movimentacoes/devolucoes",
    Component: DevolucaoProdutos,
  },
  {
    path: "/configuracoes",
    Component: Configuracoes,
  },
  {
    path: "/configuracoes/usuarios",
    Component: NiveisUsuario,
  },
  {
    path: "/configuracoes/logs",
    Component: LogsSistema,
  },
  {
    path: "/contato",
    Component: Contato,
  },
]);